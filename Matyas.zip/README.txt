﻿Adresářová struktura

--------------------------------------------------------

AndroidStudio_Projekt - Celý projekt práce včetně dokumentace


****** javaDoc - Vygenerovaná java dokumentace


****** MedicalDataCollection - Celý projekt z android studia včetně zdrojových souborů, všech konfiguračních souborů pro zbuildování projektu pomocí Gradle 
       a jednotkových testů. Celý projekt byl vyvíjen v Android studiu 1.5.1 na Ubuntu 14.04 LTS. Pro testování je ideální importovat tento project do Android studia 
       a spouštět ho pomocí emulátoru, na jehož SD kartu se musí vložit oba testovací soubory viz níže.



APKs - Dva binární soubory APK debug release, které lze spustit na mobilních zařízení Android s Android API 9 a vyšší.



Dokument - Dokument bakalářské práce

.

Testovaci_data - Dva soubory nezbytné pro testování aplikace. 


****** openEHR-EHR-OBSERVATION.sleep.v1.adl - Spánkový archetyp. Musí být na SD kartě ideálně ve složce MDC_Archetypes na kterou je aplikace defaultně nastavená. 
       Tuto složku lze v aplikaci měnit.


****** sleep-export.csv - Testovací soubor vygenerovaný aplikací SleepAsAndroid. Musí být na SD kartě ve složce jménem sleep-data, kterou SleepAsAndroid sama vytváří.
