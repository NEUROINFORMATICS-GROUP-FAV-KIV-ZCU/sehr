package com.example.root.medicaldatacollection;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * This is New Documentation Activity class.
 * This activity provides View for creating new documentation.
 *
 * Created by matyasj on 1.3.16.
 *
 * @author Jiri Matyas
 * @version 1.0
 */
public class NewDocumentationActivity extends ActionBarActivity {
    /**
     * Documentation presenter
     */
    private NewDocInterface docPresenter;
    /**
     * Text field for new documentation
     */
    private EditText docNameText;
    /**
     * Spinner for choose archetype file on SD card
     */
    private Spinner adlFilesSpinner;
    /**
     * Button for save new documentation
     */
    private Button newDocButton;
    /**
     * Spinner for choose type of new documentation
     */
    private Spinner docTypeSpinner;
    /**
     * Tag for logging
     */
    public static final String TAG = "NEW_DOC_ACTIVITY";


    /**
     * Method which is call when is this activity creating.
     *
     * @param savedInstanceState saved state of activity in their lifecycle
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /** Set up View from XML layout file */
        setContentView(R.layout.new_documentation);
        /** Initialize presenter object */
        docPresenter = DocumentationPresenter.getInstance(this.getApplicationContext());

        /** Get referenc */
        adlFilesSpinner = (Spinner) findViewById(R.id.adl_files_spinner);
        newDocButton = (Button) findViewById(R.id.save_new_doc_button);
        docNameText = (EditText) findViewById(R.id.newdocName);
        docTypeSpinner = (Spinner) findViewById(R.id.docTypeSpinner);

        setAdlFilesSpinnerAdapter(this.adlFilesSpinner);
        setNewDocButton(this.newDocButton);
        setDocTypeSpinnerAdapter(docTypeSpinner);
    }

    /**
     * This method create Menu bar from XML file (menu_main.xml)
     *
     * @param menu Action menu bar
     * @return true when is menu successfully created
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_secondary, menu);
        return true;
    }

    /**
     * This method handle action menu bar clicks
     *
     * @param item Selected item
     * @return true when the menu item was successfully handled
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            // Start of settings activity
            Intent intent = new Intent();
            intent.setClass(getApplicationContext(), SettingsActivity.class);
            startActivity(intent);
            return true;
        } else if (id == R.id.action_back) {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * This method set Spinner for choose one of archetype file on SD card
     *
     * @param adlFiles Archetype spinner
     */
    private void setAdlFilesSpinnerAdapter(Spinner adlFiles) {
        ArrayList<String> names = this.docPresenter.getArchetypeFiles();
        //  Check if is at least one archetype on sd card
        if (names.isEmpty()) {
            // if not notice user and finish activity
            Toast.makeText(getApplicationContext(), "No archetypes on SD card, please set right folder with archetypes in setting!", Toast.LENGTH_LONG).show();
            finish();
        }
        // Set adapter on array list of names
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, names);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adlFiles.setAdapter(adapter);
    }

    /**
     * This method set Spinner for choose type of documentation
     *
     * @param docTypeSpinner documentation spinner
     */
    private void setDocTypeSpinnerAdapter(Spinner docTypeSpinner) {
        // Get documentation types from presenter
        ArrayList<String> names = this.docPresenter.getDocTypeNames();
        // Set adapter
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, names);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        docTypeSpinner.setAdapter(adapter);
    }

    /**
     * This method set listener on button for saving new documentation
     *
     * @param newDocButton Button far saving new documentation
     */
    private void setNewDocButton(Button newDocButton) {

        newDocButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get documentation title
                String newDocTitle = docNameText.getText().toString();
                // Get documentation archetype name
                String archetypeFileName = adlFilesSpinner.getSelectedItem().toString();
                // Get documentation type
                String typeName = docTypeSpinner.getSelectedItem().toString();

                //Check for empty documentation title field
                if (newDocTitle.isEmpty()) {
                    docNameText.setError("Enter Documentation Name");
                    return;
                }

                // Save new documentation by presenter and save operation status
                boolean success = docPresenter.newDocumentation(newDocTitle, archetypeFileName, typeName);

                // Solve operation status
                if (success) {
                    Toast.makeText(getApplicationContext(), "New Documentation has been successfully created!", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(getApplicationContext(), "New Documentation has NOT been successfully created!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}
