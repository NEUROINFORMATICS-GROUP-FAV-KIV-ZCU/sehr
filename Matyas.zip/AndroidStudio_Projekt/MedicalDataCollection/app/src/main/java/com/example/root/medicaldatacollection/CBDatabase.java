package com.example.root.medicaldatacollection;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.Toast;

import com.couchbase.lite.CouchbaseLiteException;
import com.couchbase.lite.Database;
import com.couchbase.lite.Document;
import com.couchbase.lite.Manager;
import com.couchbase.lite.Query;
import com.couchbase.lite.QueryEnumerator;
import com.couchbase.lite.QueryRow;
import com.couchbase.lite.android.AndroidContext;
import com.couchbase.lite.replicator.Replication;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

/**
 * This class represent Database object for saving and deleting items in database.
 * This class is Singleton patern.
 *
 * Created by matyasj on 1.3.16.
 *
 * @author Jiri Matyas
 * @version 1.0
 */
public class CBDatabase implements DataInterface {
    /** Only one instance of this class */
    private static CBDatabase ourInstance;
    /** Couchbase manager object for managing databases */
    private Manager databaseManager;
    /** Database for documentation */
    private Database documentationDB;
    /** Database for measurement */
    private Database measurementDB;
    /** Application context */
    private Context appContext;
    /** URL of remote server */
    private URL syncUrl;
    /** Replication object for pushing data from documentation database on remote server */
    private Replication documentationsPushReplication;
    /** Replication object for pulling data from remote server on documentation database */
    private Replication documentationsPullReplication;
    /** Replication object for pushing data from measurement database on remote server */
    private Replication measurementsPushReplication;
    /** Replication object for pulling data from remote server on measurement database */
    private Replication measurementsPullReplication;

    /** TAG for logging */
    public static final String TAG = "CB_DATABASE";
    /** Name of documentation database */
    public static final String DOC_DB_NAME = "documentations_database";
    /** Name of documentation database */
    public static final String MEAS_DB_NAME = "measurement_database";
    /** Server address settings key */
    public static final String SERVER_URL_KEY = "remote_server_ip";
    /** Current synchronization state settings key*/
    public static final String SYNCHRONIZATION_STATE = "applicationSync";

    /**
     * Private constructor of database object
     *
     * @param context Application object
     */
    private CBDatabase(Context context) {
        this.appContext = context;

        // Creating database manager
        try {
            databaseManager = new Manager(new AndroidContext(context), Manager.DEFAULT_OPTIONS);
        } catch (IOException e) {
            Log.e(TAG, "Database manager has NOT been created!");
            e.printStackTrace();
        }

        // Creating documentation database
        try {
            documentationDB = databaseManager.getDatabase(DOC_DB_NAME);
        } catch (CouchbaseLiteException e) {
            Log.e(TAG, "Documentation's database has NOT been created!");
            e.printStackTrace();
        }

        // Creating measurement database
        try {
            measurementDB = databaseManager.getDatabase(MEAS_DB_NAME);
        } catch (CouchbaseLiteException e) {
            Log.e(TAG, "Measurement's database has NOT been created!");
            e.printStackTrace();
        }

        // Creating replication if is possible
        createReplication();
    }

    /**
     * Factory method to get database object
     *
     * @param context Application context
     * @return CBDatabase instance
     */
    public static CBDatabase getInstance(Context context) {
        if (ourInstance == null) {
            ourInstance = new CBDatabase(context);
        }

        return ourInstance;
    }

    /**
     * This method is able to save documentation into database.
     *
     * @param documentation Documentation which should be saved
     * @return String id of new saved documentation
     */
    private String saveDocumentation(Documentation documentation) {
        String newDocId = "";

        // Create new document in database
        Document newDocument = documentationDB.createDocument();
        // Get id from this created document
        newDocId = newDocument.getId();

        // Get Map representation of documentation
        Map<String, Object> map = documentation.getMapRepresentation();

        // Input data in document
        try {
            newDocument.putProperties(map);
        } catch (CouchbaseLiteException e) {
            Log.e(TAG, "Fail to save the new Document!");
            e.printStackTrace();
        }

        Log.i(TAG, "New Documentation " + newDocument.getId() + " has been successfully created!");

        return newDocId;
    }

    /**
     * This method is able to save measurement into database.
     *
     * @param measurement Measurement which should be saved
     * @return String id of new saved documentation
     */
    private String saveMeasurement(Measurement measurement) {
        String newMeasId = "";

        // Create new document in database
        Document newDocument = measurementDB.createDocument();
        // Get id from this created document
        newMeasId = newDocument.getId();
        // Get Map representation of measurement
        Map<String, Object> map = measurement.getMapRepresentation();

        // Input data in document
        try {
            newDocument.putProperties(map);
        } catch (CouchbaseLiteException e) {
            Log.e(TAG, "Fail to save the new Document!");
            e.printStackTrace();
        }

        Log.i(TAG, "New Documentation " + newDocument.getId() + "has been successfully created!");

        return newMeasId;
    }

    /**
     * This method delete documentation from database.
     *
     * @param doc Documentation object which should be deleted.
     * @return true when is properly deleted
     */
    private boolean deleteDocumentation(Documentation doc) {
        Log.i(TAG, "Deleting " + doc.getTitle() + " Database from database!");
        Document retrieveDocument = documentationDB.getDocument(doc.getId());

        //Deleting
        try {
            retrieveDocument.delete();
        } catch (CouchbaseLiteException e) {
            Log.e(TAG, doc.getTitle() + "documentation has not been successfully deleted!");
            e.printStackTrace();
        }

        //Test if document is deleted
        if (!retrieveDocument.isDeleted()) {
            Log.e(TAG, doc.getTitle() + "documentation has not been successfully deleted!!!");
        }

        return retrieveDocument.isDeleted();
    }

    /**
     * This method delete measurement from database.
     *
     * @param meas Measurement object which should be deleted.
     * @return true when is properly deleted
     */
    private boolean deleteMeasurement(Measurement meas) {
        Log.i(TAG, "Deleting " + meas.getTitle() + " Measurement from database!");
        Document retrieveDocument = measurementDB.getDocument(meas.getId());

        //Deleting
        try {
            retrieveDocument.delete();
        } catch (CouchbaseLiteException e) {
            Log.e(TAG, meas.getTitle() + " measurement has not been successfully deleted!");
            e.printStackTrace();
        }

        //Test if document is deleted
        if (!retrieveDocument.isDeleted()) {
            Log.e(TAG, meas.getTitle() + " measurement has not been successfully deleted!");
        }

        return retrieveDocument.isDeleted();
    }

    /**
     * This method save item into database.
     *
     * @param e save element
     * @return id which return Couchbase database object.
     */
    @Override
    public String saveItem(Element e) {
        if (e instanceof Measurement) {
            return saveMeasurement((Measurement) e);
        } else if (e instanceof Documentation) {
            return saveDocumentation((Documentation) e);
        }

        return "";
    }

    /**
     * This method delete element from database.
     *
     * @param e delete element
     * @return true when is element successfully deleted
     */
    @Override
    public boolean deleteItem(Element e) {
        if (e instanceof Measurement) {
            return deleteMeasurement((Measurement) e);
        } else if (e instanceof Documentation) {
            return deleteDocumentation((Documentation) e);
        }
        return false;
    }

    /**
     * This method return all documentation from database
     *
     * @return array list with all existing documentation
     */
    @Override
    public ArrayList<Documentation> getAllDocumentation() {
        ArrayList<Documentation> documentationList = new ArrayList<Documentation>();
        //Map<String, Object> allDocs = documentationDB.getAllDocs(new QueryOptions());

        Query allDocsQuery = documentationDB.createAllDocumentsQuery();
        QueryEnumerator result = null;

        try {
            result = allDocsQuery.run();
        } catch (CouchbaseLiteException e) {
            Log.e(TAG, "All documentation Query has NOT been successful started");
            e.printStackTrace();
        }

        /*  All documents loop */
        for (Iterator<QueryRow> it = result; it.hasNext(); ) {
            QueryRow row = it.next();

            Document actualDoc = row.getDocument();
            documentationList.add(Documentation.getObjectByDocument(actualDoc));
            Log.w(TAG, "Typ: " + "  --  " + actualDoc.getProperty("type") + "  Title: " + actualDoc.getProperty("title"));
        }

        return documentationList;
    }

    /**
     * This method return all measurements from database by documentation id.
     *
     * @param documentationId Documentation id
     * @return Array list of measurement
     */
    @Override
    public ArrayList<Measurement> getMeasurements(String documentationId) {
        ArrayList<Measurement> measurementList = new ArrayList<Measurement>();

        Query allMeasQuery = measurementDB.createAllDocumentsQuery();
        QueryEnumerator result = null;

        try {
            result = allMeasQuery.run();
        } catch (CouchbaseLiteException e) {
            Log.e(TAG, "All documentation Query has NOT been successful started");
            e.printStackTrace();
        }

        /*  All documents loop */
        for (Iterator<QueryRow> it = result; it.hasNext(); ) {
            QueryRow row = it.next();
            Document actualDoc = row.getDocument();

            if (actualDoc.getProperty("documentation_id").equals(documentationId)) {
                measurementList.add(Measurement.getObjectByDocument(actualDoc));
                Log.i(TAG, "Creating measurement: " + actualDoc.getProperty("title"));
            }
        }

        return measurementList;
    }


    /**
     * This method serving synchronization of documentation and measurement database with remote
     * server. Method can start and stop synchronization by input parameter.
     *
     * @param sync true when synchronization should start
     */
    public boolean synchronization(boolean sync) {
        boolean syncSuccess = true;
        // Test if synchronization should start
        if (sync) {
            // Test if is database replication created
            if (documentationsPushReplication != null) {
                documentationsPushReplication.start();
            } else {
                syncSuccess = false;
                Log.e(TAG, "Documentation Push Replication is null. Probably sync URL is malformed!");
            }
            if (documentationsPullReplication != null) {
                documentationsPullReplication.start();
            } else {
                syncSuccess = false;
                Log.e(TAG, "Documentation Pull Replication is null. Probably sync URL is malformed!");
            }
            if (measurementsPushReplication != null) {
                measurementsPushReplication.start();
            } else {
                syncSuccess = false;
                Log.e(TAG, "Measurement Push Replication is null. Probably sync URL is malformed!");
            }
            if (measurementsPullReplication != null) {
                measurementsPullReplication.start();
            } else {
                syncSuccess = false;
                Log.e(TAG, "Measurement Pull Replication is null. Probably sync URL is malformed!");
            }

            // Info for user if is synchronization successfully
            if (!syncSuccess) {
                Toast.makeText(this.appContext, "Synchronization faild! Server URL is probably malformed!", Toast.LENGTH_LONG).show();
            }else{
                Toast.makeText(this.appContext, "Synchronization is running!", Toast.LENGTH_SHORT).show();
            }

        } else {
            if (documentationsPushReplication != null) {
                documentationsPushReplication.stop();
            }
            if (documentationsPullReplication != null) {
                documentationsPullReplication.stop();
            }
            if (measurementsPushReplication != null) {
                measurementsPushReplication.stop();
            }
            if (measurementsPullReplication != null) {
                measurementsPullReplication.stop();
            }

            Toast.makeText(this.appContext, "Synchronization is off!", Toast.LENGTH_SHORT).show();
        }
        return syncSuccess;
    }

    /**
     * This method create database replication objects which synchronize data with remote server.
     */
    public void createReplication() {
        // Get application shared preferences
        SharedPreferences SP = PreferenceManager.getDefaultSharedPreferences(this.appContext);
        // Get Server URL from application settings
        String preferencesURL = SP.getString(SERVER_URL_KEY, "NA");
        // Get synchronization state
        boolean sync = SP.getBoolean(SYNCHRONIZATION_STATE, false);

        boolean isRunning = false;
        if (documentationsPushReplication != null) {
            isRunning = documentationsPushReplication.isRunning();
        }

        if (isRunning) {
            documentationsPushReplication.stop();
            documentationsPullReplication.stop();
            measurementsPushReplication.stop();
            measurementsPushReplication.stop();
        }

        try {
            syncUrl = new URL(preferencesURL);
        } catch (MalformedURLException e) {
            Log.e(TAG, "Malformed synchronization URL!" + preferencesURL);
            Toast.makeText(this.appContext, "Malformed URL for synchronization is provided!", Toast.LENGTH_LONG).show();
            return;
        }

        documentationsPullReplication = documentationDB.createPullReplication(syncUrl);
        documentationsPullReplication.setContinuous(true);

        documentationsPushReplication = documentationDB.createPushReplication(syncUrl);
        documentationsPushReplication.setContinuous(true);

        measurementsPullReplication = documentationDB.createPullReplication(syncUrl);
        measurementsPullReplication.setContinuous(true);

        measurementsPushReplication = documentationDB.createPushReplication(syncUrl);
        measurementsPushReplication.setContinuous(true);

        if (sync) {
            documentationsPushReplication.start();
            documentationsPullReplication.start();
            measurementsPushReplication.start();
            measurementsPushReplication.start();
        }
    }

}
