package com.example.root.medicaldatacollection;

import android.content.Context;
import android.widget.LinearLayout;

import com.couchbase.lite.Document;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * This class represent common Documentation.
 * This class is abstract class. Is not possible create common Documentation.
 * <p/>
 * Created by matyasj on 28.2.16.
 *
 * @author Jiri Matyas
 * @version 1.0
 */
public abstract class Documentation extends Element {
    /**
     * List of measurement
     */
    protected ArrayList<Measurement> measurementList;
    /**
     * Archetype string from file
     */
    protected String archetypeString;
    /**
     * Documentation type
     */
    protected String type;

    /**
     * title tag for creating map representation and creating documentation from this map representation
     */
    public static String TITLE_TAG = "title";
    /**
     * archetype string tag for creating map representation and creating documentation from this map representation
     */
    public static String ARCHETYPE_STRING_TAG = "archetype_string";
    /**
     * type tag for creating map representation and creating documentation from this map representation
     */
    public static String TYPE_TAG = "type";

    /**
     * Constructor of common Documentation.
     *
     * @param id              id of documentation
     * @param title           title of documentation
     * @param archetypeString archetype string from archetype file
     * @param type            type of documentation
     */
    public Documentation(String id, String title, String archetypeString, String type) {
        super(id, title);

        this.archetypeString = archetypeString;
        this.measurementList = new ArrayList<Measurement>();
        this.type = type;
    }

    /**
     * This method create HashMap representation of documentation for saving into database.
     *
     * @return HashMap representation of documentation
     */
    public HashMap<String, Object> getMapRepresentation() {
        HashMap<String, Object> map = new HashMap<String, Object>();

        map.put(TITLE_TAG, this.getTitle());
        map.put(ARCHETYPE_STRING_TAG, this.archetypeString);
        map.put(TYPE_TAG, this.type);

        return map;
    }

    //Abstract method for creatyng layout and getting data from this layout
    public abstract LinearLayout createDataLayout(Context context, NewMeasurementActivity activity);

    public abstract LinearLayout createProtocolLayout(Context context);

    public abstract LinearLayout createPropertiesLayout(Context context, NewMeasurementActivity activity);

    public abstract HashMap<String, Object> getNewMeasData();

    public abstract HashMap<String, Object> getNewMeasProtocol();

    public abstract HashMap<String, Object> getNewMeasObjectModel();

    //public abstract String getType();

    /**
     * Factory method for creating documentation instance from database document.
     *
     * @param doc database document
     * @return Documentation instance
     */
    public static Documentation getObjectByDocument(Document doc) {
        Documentation newDoc = null;
        String title = (String) doc.getProperty(TITLE_TAG);
        String archetypeString = (String) doc.getProperty(ARCHETYPE_STRING_TAG);
        String type = (String) doc.getProperty(TYPE_TAG);

        if (type.equals(SleepDocumentation.DOC_TYPE)) {
            newDoc = new SleepDocumentation(doc.getId(), title, archetypeString);
        }

        return newDoc;
    }
}