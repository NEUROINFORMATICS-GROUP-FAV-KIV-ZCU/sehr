package com.example.root.medicaldatacollection;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

/**
 * This class representing activity which provide View for creating new Measurement.
 *
 * Created by matyasj on 1.3.16.
 *
 * @author Jiri Matyas
 * @version 1.0
 */
public class NewMeasurementActivity extends ActionBarActivity {
    /**
     * Measurement presenter
     */
    private NewMeasInterface presenter;
    /**
     * Measurement's documentation id
     */
    private String docId;
    /**
     * Button for saving new measurement
     */
    private Button saveNewMeasurementBtn;
    /**
     * Title text field of new Measurement
     */
    private EditText titleField;
    /**
     * Layout of data part of view
     */
    private LinearLayout dataLayout;
    /**
     * Layout of protocol part of view
     */
    private LinearLayout protocolLayout;
    /**
     * Layout of properties part of layout
     */
    private LinearLayout properties;

    /**
     * Tag for logging
     */
    public static final String TAG = "NEW_MEAS_ACTIVITY";

    /**
     * Method which is call when is this activity creating.
     *
     * @param savedInstanceState saved state of activity in their lifecycle
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set View of activity
        setContentView(R.layout.new_measurement);
        // Get intent for geting input data
        Intent intent = getIntent();
        // Initialization of this activity
        init(intent);
    }

    /**
     * This method create Menu bar from XML file (menu_main.xml)
     *
     * @param menu Action menu bar
     * @return true when is menu successfully created
     */
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action menu bar if it is present.
        getMenuInflater().inflate(R.menu.menu_secondary, menu);
        return true;
    }

    /**
     * This method handle action menu bar clicks
     *
     * @param item Selected item
     * @return true when the menu item was successfully handled
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // The action bar will automatically handle clicks on the
        // Home/Up button, so long as you specify a parent activity
        // in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            // Start of settings activity
            Intent intent = new Intent();
            intent.setClass(getApplicationContext(), SettingsActivity.class);
            startActivity(intent);
            return true;
        } else if (id == R.id.action_back) {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }


    /**
     * Initialization method of this activity
     *
     * @param intent intent necessary for getting input parameter
     */
    private void init(Intent intent) {
        // Getting documentation id from intent object
        this.docId = intent.getStringExtra("documentation_id");
        // Getting measurement presenter by factory method
        this.presenter = MeasurementPresenter.getInstanceByDocID(docId);

        // Get button for save new measurement
        this.saveNewMeasurementBtn = (Button) findViewById(R.id.save_new_meas_button);
        // Get text field of title of new measurement
        this.titleField = (EditText) findViewById(R.id.newMeasTitleField);
        // Setting title of new measurement on default title
        this.titleField.setText(R.string.default_title);

        // Get data layout from view
        this.dataLayout = (LinearLayout) findViewById(R.id.NewMeasData);
        // Get protocol layout from view
        this.protocolLayout = (LinearLayout) findViewById(R.id.NewMeasProtocol);
        // Get properties layout from view
        this.properties = (LinearLayout) findViewById(R.id.NewMeasProperties);

        // Set title of view from presenter
        this.setTitle(presenter.getNewMeasureTitle());

        // Set layout of three part of view
        setLayout(true);

        // Set listener to saving button
        setSaveListener();
    }

    /**
     * Setting layout of data, protocol and properties part of view. Data and protocol part is taken
     * from module. In properties part is module spinner for choose.
     *
     * @param isNew When false is method will update view when true method will create new view
     */
    public void setLayout(boolean isNew) {
        // Context is necessary for creating new view component
        Context context = NewMeasurementActivity.this;
        LinearLayout propertiesL = null;
        // test if is necessary to create new propertiesLayout
        if (isNew) {
            propertiesL = presenter.getPropertiesLayout(context, this.dataLayout, this.protocolLayout, this);
        }
        // Get data part of view from presenter
        LinearLayout dataL = presenter.getDataLayout(context, this);
        // Get protocol part of view from presenter
        LinearLayout protocolL = presenter.getProtocolLayout(context);

        // if data layout is not good created
        if (dataL != null) {
            // test if is data layout empty
            if (this.dataLayout.getChildCount() != 0) {
                this.dataLayout.removeAllViews();
            }
            this.dataLayout.addView(dataL);
        } else {
            Log.e(TAG, "Data layout is null");
        }

        // if protocol layout is not good created
        if (protocolL != null) {
            // test if is protocol layout empty
            if (this.protocolLayout.getChildCount() != 0) {
                this.protocolLayout.removeAllViews();
            }
            this.protocolLayout.addView(protocolL);
        } else {
            this.protocolLayout.removeAllViews();
            Log.e(TAG, "Protocol layout is null");
        }

        if (propertiesL != null && isNew) {
            if (this.properties.getChildCount() != 0) {
                this.properties.removeAllViews();
            }
            this.properties.addView(propertiesL);
        } else {
            Log.e(TAG, "Protocol layout is null");
        }

    }

    /**
     * Set listener for save Button
     */
    private void setSaveListener() {
        this.saveNewMeasurementBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean success = false;

                // Get title for testing, if is empty
                String title = titleField.getText().toString();

                if (title.isEmpty()) {
                    titleField.setError("Enter measurement title");
                    return;
                }

                // true if is new measurement successfully saved
                success = presenter.newMeasurement(title);
                if (success) {
                    // Show success message to user
                    Toast.makeText(getApplicationContext(), "New Measurement has been successfully created!", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });
    }
}
