package com.example.root.medicaldatacollection;

import android.content.Context;
import android.widget.LinearLayout;

import java.util.HashMap;

/**
 * This interface provide communication between Modules and rest of application
 *
 * Created by matyasj on 17.3.16.
 *
 * @author Jiri Matyas
 * @version 1.0
 */
public interface Modulable {

    /**
     * This method get data part of new measurement
     *
     * @return HashMap with data information
     */
    HashMap<String, Object> getData();
    /**
     * This method get protocol part of new measurement
     *
     * @return HashMap with protocol information
     */
    HashMap<String, Object> getProtocol();
    /**
     * This method get object model of new measurement
     *
     * @return HashMap with data information
     */
    HashMap<String, Object> getObjectModel();

    /**
     * This Method return name of module
     *
     * @return String name of module
     */
    String toString();

    /**
     * This method return data part layout for view of new measurement.
     *
     * @param context application context for creating components
     * @param activity Activity for callback
     * @return LinearLayout of data part of new measurement
     */
    LinearLayout getDataLayout(Context context, NewMeasurementActivity activity);
    /**
     * This method return protocol part layout for view of new measurement.
     *
     * @param context application context for creating components
     * @return LinearLayout of data part of new measurement
     */
    LinearLayout getProtocolLayout(Context context);
}
