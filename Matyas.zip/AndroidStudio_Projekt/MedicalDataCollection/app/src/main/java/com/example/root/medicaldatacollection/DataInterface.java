package com.example.root.medicaldatacollection;

import java.util.ArrayList;

/**
 * This interface provide communication between presenters and database object
 *
 * Created by matyasj on 1.3.16.
 *
 * @author Jiri Matyas
 * @version 1.0
 */
public interface DataInterface {
    /**
     * This method save item into database.
     *
     * @param e save element
     * @return id which return Couchbase database object.
     */
    String saveItem(Element e);

    /**
     * This method delete element from database.
     *
     * @param e delete element
     * @return true when is element successfully deleted
     */
    boolean deleteItem(Element e);

    /**
     * This method return all documentation from database
     *
     * @return array list with all existing documentation
     */
    ArrayList<Documentation> getAllDocumentation();

    /**
     * This method return all measurements from database by documentation id.
     *
     * @param documentationId Documentation id
     * @return Array list of measurement
     */
    ArrayList<Measurement> getMeasurements(String documentationId);
}
