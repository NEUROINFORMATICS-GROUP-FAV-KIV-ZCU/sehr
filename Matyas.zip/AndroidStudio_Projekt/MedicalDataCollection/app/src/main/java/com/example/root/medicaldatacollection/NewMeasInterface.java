package com.example.root.medicaldatacollection;

import android.content.Context;
import android.widget.LinearLayout;

/**
 * This interface provide communication between New measurement activity and Measurement presenter
 *
 * Created by matyasj on 2.3.16.
 *
 * @author Jiri Matyas
 * @version 1.0
 */
public interface NewMeasInterface {

    /**
     * Send requirement to presenter for creating new measurement.
     *
     * @param title Name of new measurement
     * @return return true if is new measurement successfully saved in database
     */
    boolean newMeasurement(String title);

    /**
     * This method create data layout for  New Measurement Activity.
     *
     * @param context Application context
     * @param activity New Measurement activity for callback functions.
     * @return LinearLayout of data part of layout
     */
    LinearLayout getDataLayout(Context context, NewMeasurementActivity activity);
    /**
     * This method create protocol layout for  New Measurement Activity.
     *
     * @param context Application context
     * @return LinearLayout of protocol part of layout
     */
    LinearLayout getProtocolLayout(Context context);

    /**
     * This method create properties layout for  New Measurement Activity.
     *
     * @param context Application context
     * @param dataLayout data layout
     * @param protocolLayout protocol layout
     * @param activity New Measurement activity for callback functions.
     * @return
     */
    LinearLayout getPropertiesLayout(Context context, LinearLayout dataLayout, LinearLayout protocolLayout, NewMeasurementActivity activity);

    /**
     * This method return title of new measurement activity
     * @return
     */
    String getNewMeasureTitle();

}
