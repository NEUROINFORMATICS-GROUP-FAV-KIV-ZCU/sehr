package com.example.root.medicaldatacollection;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 * This class represent documentation presenter object.
 * This presenters provide information for activity which works with documentation and getting user
 * callbacks.
 * This class is Singleton pattern. It is not necessary to have more than one instance of documentation
 * presenter.
 * <p/>
 * Created by matyasj on 1.3.16.
 *
 * @author Jiri Matyas
 * @version 1.0
 */
public class DocumentationPresenter implements Presentable, NewDocInterface {
    /**
     * This is only one Singleton instance of this class
     */
    private static DocumentationPresenter ourInstance;
    /**
     * Array list of all exist documentation
     */
    private ArrayList<Documentation> documentationList;
    /**
     * Database object
     */
    private DataInterface database;
    /**
     * Application context
     */
    private Context appContext;
    /**
     * Archetype folder name on SD card
     */
    private String archetypeFolderOnSD;
    /**
     * SD card folder
     */
    private File sdCard;

    /**
     * TAG for logging
     */
    public final String TAG = "DOC PUBLISHER";
    /**
     * Archetype suffix
     */
    public final String ARCHETYPE_SUFFIX = ".adl";

    /**
     * Name of this application
     */
    public static final String APP_NAME = "Medical Data Collection";

    /**
     * Archetype folder name key from application settings.
     */
    public final String ARCHETYPE_FOLDER_PREFERENCE = "arch_folder";

    /**
     * Private constructor of this class
     *
     * @param con
     */
    private DocumentationPresenter(Context con) {
        this.appContext = con;
        // Get database object by factory method
        this.database = CBDatabase.getInstance(con);
        // Get list of all documentation from database
        this.documentationList = this.database.getAllDocumentation();
        // Get SD card folder
        this.sdCard = Environment.getExternalStorageDirectory();
    }

    /**
     * Factory method to get only one instance of this class. This is only way to get documentation
     * presenter
     *
     * @param context Application context for creating view components
     * @return return Documentation presenter object
     */
    public static DocumentationPresenter getInstance(Context context) {
        if (ourInstance == null) {
            ourInstance = new DocumentationPresenter(context);
        }
        return ourInstance;
    }


    /**
     * This method get List of documentation
     *
     * @return List of requested documentation
     */
    @Override
    public ArrayList<String> getNameList() {
        ArrayList<String> list = new ArrayList<String>();

        for (Documentation d : documentationList) {
            list.add(d.getTitle());
        }

        return list;
    }

    /**
     * This method return id by documentation title
     *
     * @param title item documentation
     * @return documentation id
     */
    @Override
    public String getIdByTitle(String title) {
        String id = "";

        for (Documentation d : documentationList) {
            if (d.title == title) {
                id = d.getId();
                break;
            }
        }

        return id;
    }

    /**
     * This method return title of activity
     *
     * @return activity title
     */
    @Override
    public String getName() {
        return APP_NAME;
    }

    /**
     * This method delete documentation by title
     *
     * @param title title of deleting documentation
     * @return true if is documentation successfully deleted
     */
    @Override
    public boolean deleteItem(String title) {
        String id = this.getIdByTitle(title);

        Documentation deletedDoc;

        for (int i = 0; i < this.documentationList.size(); i++) {
            if (this.documentationList.get(i).getId() == id) {
                deletedDoc = this.documentationList.remove(i);

                return this.database.deleteItem(deletedDoc);
            }
        }
        return false;
    }

    /**
     * This method create new documentation. If is creating successful presenter return true to
     * activity. This new Documentation save into database.
     *
     * @param title             title of documentation
     * @param archetypeFileName name of archetype name
     * @param type              type of documentation
     * @return true when is saving successful
     */
    @Override
    public boolean newDocumentation(String title, String archetypeFileName, String type) {
        String archetypeString = "";
        String newID = "";

        // Test loop if already exist documentation with same name
        for (Documentation doc : this.documentationList) {
            if (doc.getTitle().equals(title)) {
                Toast.makeText(this.appContext, "This database title already exist!", Toast.LENGTH_SHORT).show();
                return false;
            }
        }

        archetypeString = getArchetypeString(archetypeFileName);

        /*First give new Documentation empty String ID*/
        Documentation newDoc = null;

        if (type.equals(SleepDocumentation.DOC_TYPE_NAME)) {
            newDoc = new SleepDocumentation(newID, title, archetypeString);
        }

        // Save into database
        newID = this.database.saveItem(newDoc);

        // Test if is saving successful
        if (newID == "") {
            return false;
        } else {
            /* There set new ID from database */
            newDoc.setId(newID);
            this.documentationList.add(newDoc);
            return true;
        }
    }

    /**
     * This method return all archetype names in archetype folder on SD card
     *
     * @return Array list of archetype names
     */
    @Override
    public ArrayList<String> getArchetypeFiles() {
        ArrayList<String> listOfNames = new ArrayList<String>();
        // Get Application preferences.
        SharedPreferences SP = PreferenceManager.getDefaultSharedPreferences(this.appContext);
        String strUserName = SP.getString(ARCHETYPE_FOLDER_PREFERENCE, "NA");

        this.archetypeFolderOnSD = strUserName;
        File archetypeFolder = new File(this.sdCard + File.separator + archetypeFolderOnSD);
        boolean folderCreated;

        //Test if folder exist
        if (!archetypeFolder.exists()) {
            Log.e(TAG, "Archetype folder {" + archetypeFolder.getPath() + "} is not on on SD Card!!! Try to create.");
            folderCreated = archetypeFolder.mkdir();
            if (folderCreated) {
                Log.e(TAG, "Archetype folder has been successfully created!");
            } else {
                Log.e(TAG, "Archetype folder has NOT been successfully created!");
            }

            return listOfNames;
        }

        // Loop for all file in archetype folder
        for (File f : archetypeFolder.listFiles()) {
            // Test if is file archetype
            if (isFileArchetype(f)) {
                listOfNames.add(f.getName());
            }
        }

        return listOfNames;
    }

    /**
     * This method return Array list of all documentation types
     *
     * @return Array list of documentation types
     */
    @Override
    public ArrayList<String> getDocTypeNames() {
        ArrayList<String> docTypes = new ArrayList<String>();

        docTypes.add(SleepDocumentation.DOC_TYPE_NAME);

        return docTypes;
    }

    /**
     * This method return archetype string which method read from file.
     *
     * @param ArchetypeFileName archetype file name
     * @return Archetype string
     */
    private String getArchetypeString(String ArchetypeFileName) {
        String archetypeText = "";
        File archetype = new File(this.sdCard + File.separator + archetypeFolderOnSD + File.separator + ArchetypeFileName);

        if (!archetype.exists()) {
            Log.e(TAG, "Required file " + archetype.getName() + " not exist!!!");
        }

        archetypeText = readAllFile(archetype);

        return archetypeText;
    }

    /**
     * Test if is file archetype.
     *
     * @param file potential archetype file
     * @return true if is file archetype
     */
    private boolean isFileArchetype(File file) {
        boolean isArchetype = false;
        String name = file.getName();
        String suffix = name.substring((file.getName().length() - 4), (file.getName().length()));

        if (suffix.equals(ARCHETYPE_SUFFIX)) {
            isArchetype = true;
        }

        return isArchetype;
    }

    /**
     * Read all content from file.
     *
     * @param file file
     * @return All string from file
     */
    private String readAllFile(File file) {
        String text = "";

        BufferedReader br = null;
        try {
            //  Create bufferedreader with bigger buffer
            br = new BufferedReader(new FileReader(file), 8192);
        } catch (FileNotFoundException e) {
            Log.e(TAG, "File Not Found Exception");
        }

        String line = "";

        try {
            line = br.readLine();
            while (line != null) {
                Log.e(TAG, line);
                text += line;
                line = br.readLine();
            }
            br.close();
        } catch (IOException e) {
            Log.e(TAG, "Input/Output Exception");
        }

        return text;
    }

    /**
     * Get documentation by documentation id. This method use measurement presenter.
     *
     * @param docId documentation id
     * @return Documentation instance
     */
    public Documentation getDocumentationById(String docId) {
        // Try to find documentation in own documentation list
        for (Documentation doc : this.documentationList) {
            if (doc.getId().equals(docId)) {
                return doc;
            }
        }

        return null;
    }
}
