package com.example.root.medicaldatacollection;

import java.util.HashMap;

/**
 * This interface provide communication between Detail measurement activity and Measurement presenter
 *
 * Created by matyasj on 2.3.16.
 *
 * @author Jiri Matyas
 * @version 1.0
 */
public interface MeasDetailInterface{

    /**
     * This method return detail data information of measurement by measurement id.
     *
     * @param measId Measurement id
     * @return HashMap with detail data information
     */
    HashMap<String, Object> getDetailData(String measId);
    /**
     * This method return detail protocol information of measurement by measurement id.
     *
     * @param measId Measurement id
     * @return HashMap with detail protocol information
     */
    HashMap<String, Object> getDetailProtocol(String measId);

    /**
     * Get measurement name by id
     *
     * @param measId Measurement id
     * @return Meaurement name
     */
    String getMeasureName(String measId);
}
