package com.example.root.medicaldatacollection;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * This class representing activity which provide measurement list view.
 * This view show list of existing measurement of one documentation.
 *
 * Created by matyasj on 4.3.16.
 *
 * @author Jiri Matyas
 * @version 1.0
 */
public class MeasurementListActivity extends ActionBarActivity {
    /**
     * Name of measurement list
     */
    private String listName;
    ;
    /**
     * Measurement documentation id
     */
    private String docId;
    /**
     * Measurement presenter
     */
    private Presentable presenter;
    private ArrayAdapter adapter;

    /**
     * TAG for logging
     */
    public static final String TAG = "LIST_MEAS_ACTIVITY";
    public static final String DOCUMENTATION_ID_TAG = "documentation_id";
    public static final String MEASUREMENT_ID_TAG = "measurement_id";

    /**
     * Method which is call when is this activity creating.
     *
     * @param savedInstanceState saved state of activity in their lifecycle
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_of_items);
        Intent intent = getIntent();
        init(intent);
    }

    /**
     * This method create Menu bar from XML file (menu_main.xml)
     *
     * @param menu Action menu bar
     * @return true when is menu successfully created
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_secondary, menu);
        return true;
    }

    /**
     * This method handle action menu bar clicks
     *
     * @param item Selected item
     * @return true when the menu item was successfully handled
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();


        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            // Start of settings activity
            Intent intent = new Intent();
            intent.setClass(getApplicationContext(), SettingsActivity.class);
            startActivity(intent);
            return true;
        } else if (id == R.id.action_back) {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * When resume this activity have to create measurement list again.
     * New measurement can by created.
     */
    @Override
    public void onResume() {
        super.onResume();
        printListOfItems(this.docId);
    }

    /**
     * This method print and create list of existing measurement from documentation.
     *
     * @param docId id of documentation of measurement list
     */
    private void printListOfItems(final String docId) {
        // Get list of measurement names from presenter
        ArrayList<String> measurementNames = presenter.getNameList();

        final ListView listOfMeasure = (ListView) findViewById(R.id.itemsList);

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, measurementNames);

        listOfMeasure.setAdapter(adapter);
        listOfMeasure.setClickable(true);

        // Set click listener for show detail information of measurement
        listOfMeasure.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Object chosen = listOfMeasure.getItemAtPosition(position).toString();
                getItemDetail(chosen.toString(), docId);
            }
        });

        // Set long click listener for deleting measurement
        listOfMeasure.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

            public boolean onItemLongClick(AdapterView<?> arg0, View v, int position, long arg3) {
                String chosen = listOfMeasure.getItemAtPosition(position).toString();
                popUpAlert(chosen);

                return true;
            }
        });

    }

    /**
     * This method create measurement detail activity
     *
     * @param itemName Name of item
     * @param docId    Id of documentation which this measurement belongs
     */
    private void getItemDetail(String itemName, String docId) {
        String idMeas = presenter.getIdByTitle(itemName);

        final Intent intent = new Intent();
        intent.setClass(getApplicationContext(), MeasurementDetailActivity.class);
        // Put parameters for Measurement detail activity
        intent.putExtra(MEASUREMENT_ID_TAG, idMeas);
        intent.putExtra(DOCUMENTATION_ID_TAG, docId);

        startActivity(intent);
    }

    /**
     * This method create new measurement activity, when user click on new measurement button.
     *
     * @param docId Id of documentation
     */
    private void newMeasure(String docId) {
        final Intent intent = new Intent();
        intent.setClass(getApplicationContext(), NewMeasurementActivity.class);
        intent.putExtra(DOCUMENTATION_ID_TAG, docId);

        startActivity(intent);
    }

    /**
     * This is inizialization method of activity
     *
     * @param intent Intent object for getting input parameters.
     */
    private void init(Intent intent) {
        this.docId = intent.getStringExtra(DOCUMENTATION_ID_TAG);
        this.presenter = new MeasurementPresenter(docId, this.getApplicationContext());

        this.listName = this.presenter.getName();

        this.setTitle(listName);

        //Set up new measure button listener
        final Button button = (Button) findViewById(R.id.newMeasureButton);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                newMeasure(docId);
            }
        });

        ///Set up list of measure
        printListOfItems(docId);
    }


    /**
     * This method pop up alert before deleting measurement.
     *
     * @param chosen Name of deleting measurement
     */
    private void popUpAlert(final String chosen) {
        final String chosenItem = chosen;

        // Set pop up alert builder
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure you want to delete this measurement?")
                .setTitle("Delete Measurement")
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        if (presenter.deleteItem(chosenItem)) {
                            adapter.remove(chosen);
                            adapter.notifyDataSetChanged();
                            Toast.makeText(getApplicationContext(), "Measurement " + chosenItem + " has been deleted!", Toast.LENGTH_SHORT).show();
                        }

                    }
                });

        // Create and show pop up alert
        builder.create().show();
    }
}
