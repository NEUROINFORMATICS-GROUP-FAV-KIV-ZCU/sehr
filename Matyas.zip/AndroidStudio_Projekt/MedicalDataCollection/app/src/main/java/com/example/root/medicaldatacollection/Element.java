package com.example.root.medicaldatacollection;

/**
 * This class represent every element for save into database.
 * Object of this class are base building blocks for data model.
 * <p/>
 * Created by matyasj on 28.2.16.
 *
 * @author Jiri Matyas
 * @version 1.0
 */
public class Element {
    /**
     * Id of element
     */
    protected String id;
    /**
     * Title of element
     */
    protected String title;


    /**
     * Constructor of element
     *
     * @param id    Id
     * @param title Title
     */
    public Element(String id, String title) {
        this.id = id;
        this.title = title;
    }

    /**
     * Id getter
     *
     * @return id
     */
    public String getId() {
        return id;
    }

    /**
     * Title getter
     *
     * @return title
     */
    public String getTitle() {
        return title;
    }

    /**
     * Id setter. This method is used for set id after saving item into database
     *
     * @param newId New element id
     */
    public void setId(String newId) {
        this.id = newId;
    }

}
