package com.example.root.medicaldatacollection;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

import modules.sleepAsAndroid.SleepAsAndroidModule;


/**
 * This class representing sleep documentation and extends common Documentation.
 * Object of this class should create layout of new measurement of this class. In this class
 * is use Sleep As Android module.
 * <p/>
 * Created by matyasj on 3.3.16.
 *
 * @author Jiri Matyas
 * @version 1.0
 */
public class SleepDocumentation extends Documentation {
    /**
     * Array list of sleep modules
     */
    private ArrayList<Modulable> modules;
    /**
     * Id of currently selected module
     */
    private int selectedModule;

    /**
     * String representation of type of sleep documentation
     */
    public static final String DOC_TYPE = "SLEEP_DOC";
    /**
     * String representation name of sleep documentation
     */
    public static final String DOC_TYPE_NAME = "Sleep documentation";
    /**
     * TAG for logging
     */
    public static final String TAG = "SLEEP_DOCUMENTATION";

    /**
     * Constructor of Sleep documentation.
     *
     * @param id              Id of new sleep documentation
     * @param title           Title of new documentation
     * @param archetypeString String of sleep archetype
     */
    public SleepDocumentation(String id, String title, String archetypeString) {
        super(id, title, archetypeString, DOC_TYPE);
        // Creating new array list of modules
        modules = new ArrayList<Modulable>();
        // Add Sleep As Android modul into array list of modules
        modules.add(new SleepAsAndroidModule());
        // First selected module is the first one
        this.selectedModule = 0;
        Log.i(TAG, "SleepAsAndroid modul creating");
    }

    /**
     * Create data layout of new measurement view
     *
     * @param context  Application context
     * @param activity NewMeasurementActivity for callback
     * @return Linear layout of data part of new measurement layout.
     */
    @Override
    public LinearLayout createDataLayout(Context context, NewMeasurementActivity activity) {
        LinearLayout data = modules.get(selectedModule).getDataLayout(context, activity);
        return data;
    }


    /**
     * Create protocol layout of new measurement view
     *
     * @param context Application context
     * @return Linear layout of data part of new measurement layout.
     */
    @Override
    public LinearLayout createProtocolLayout(Context context) {
        LinearLayout protocolLayout = modules.get(selectedModule).getProtocolLayout(context);
        return protocolLayout;
    }

    /**
     * This method create properties part of new measurement layout. There will be spinner of modules.
     *
     * @param context  Application context for creating components
     * @param activity
     * @return
     */
    @Override
    public LinearLayout createPropertiesLayout(Context context, NewMeasurementActivity activity) {
        LinearLayout layout = new LinearLayout(context);
        layout.setBackgroundColor(Color.GRAY);
        layout.setOrientation(LinearLayout.VERTICAL);

        //Set module spinner
        Spinner moduleSpinner = new Spinner(context);

        ArrayAdapter<Modulable> adapter;
        adapter = new ArrayAdapter<Modulable>(context, android.R.layout.simple_spinner_item, this.modules);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        moduleSpinner.setAdapter(adapter);

        setModuleSpinnerListener(moduleSpinner, activity);

        LinearLayout moduleField = getField("Choose module", moduleSpinner, context);

        layout.addView(moduleField);

        if (layout == null) {
            Log.e("DOC", "Layout je null");
        }

        return layout;
    }

    /**
     * This is help method for creating form field with label.
     *
     * @param title     title/label of component
     * @param component View component
     * @param context   Application context for creating labels
     * @return LinearLayout field
     */
    private LinearLayout getField(String title, View component, Context context) {
        LinearLayout field = new LinearLayout(context);
        field.setOrientation(LinearLayout.HORIZONTAL);
        TextView label = new TextView(context);
        label.setText(title);
        field.addView(label, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        field.addView(component, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        return field;
    }

    /**
     * This method set sleep module spinner for choosing module for getting sleep data.
     *
     * @param spinner  module spinner
     * @param activity NewMeasurementActivity for callback
     */
    private void setModuleSpinnerListener(final Spinner spinner, final NewMeasurementActivity activity) {
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                // Callback for activity with only update settings
                activity.setLayout(false);
                // select module
                selectedModule = (int) id;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                Log.e(TAG, "You choose nothing");
            }

        });
    }

    /**
     * New measurement data getter
     *
     * @return HashMap with new measurement data
     */
    @Override
    public HashMap<String, Object> getNewMeasData() {
        return this.modules.get(selectedModule).getData();
    }

    /**
     * New measurement protocol getter
     *
     * @return HashMap with protocol measurement data
     */
    @Override
    public HashMap<String, Object> getNewMeasProtocol() {
        return this.modules.get(selectedModule).getProtocol();
    }

    /**
     * New measurement object protocol getter
     *
     * @return HashMap with new measurement object protocol
     */
    @Override
    public HashMap<String, Object> getNewMeasObjectModel() {
        return this.modules.get(selectedModule).getObjectModel();
    }
}
