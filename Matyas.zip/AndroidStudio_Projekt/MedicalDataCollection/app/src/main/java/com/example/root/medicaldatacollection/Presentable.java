package com.example.root.medicaldatacollection;

import java.util.ArrayList;

/**
 * This interface provide communication between list activities and presenters
 *
 * Created by matyasj on 1.3.16.
 *
 * @author Jiri Matyas
 * @version 1.0
 */
public interface Presentable {

    /**
     * This method get List of items
     *
     * @return List of requested items
     */
    ArrayList<String> getNameList();

    /**
     * This method return id by item title
     *
     * @param title item title
     * @return item id
     */
    String getIdByTitle(String title);

    /**
     * This method return title of activity
     *
     * @return activity title
     */
    String getName();

    /**
     * This method delete item by title
     *
     * @param title title of deleting item
     * @return true if is item successfully deleted
     */
    boolean deleteItem(String title);
}
