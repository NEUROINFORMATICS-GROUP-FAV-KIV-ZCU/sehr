package com.example.root.medicaldatacollection;


import android.content.Context;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

/**
 * This class represent measurement presenter objects.
 * This presenters provide information for activity which works with measurement and getting user
 * callbacks.
 *
 * Created by matyasj on 2.3.16.
 *
 * @author Jiri Matyas
 * @version 1.0
 */
public class MeasurementPresenter implements Presentable, NewMeasInterface, MeasDetailInterface {
    /**
     * Parent documentation of measurement this presenter work with
     */
    private Documentation parentDoc;
    /**
     * Array list of measurement this presenter work with
     */
    private ArrayList<Measurement> measurementList;
    /**
     * Database object
     */
    private DataInterface database;
    /**
     * Documentation presenter for getting parent documentation
     */
    private DocumentationPresenter docPresenter;
    /**
     * Application context
     */
    private Context appContext;
    /**
     * Array list of measurement presenter for repeat use of these objects
     */
    private static ArrayList<MeasurementPresenter> listOfObject = new ArrayList<>();
    /**
     * TAG for logging
     */
    private static final String TAG = "MEAS PUBLISHER";

    /**
     * Constructor of Measurement presenter
     *
     * @param docId Id of parent documentation
     * @param con   Application context
     */
    public MeasurementPresenter(String docId, Context con) {
        this.appContext = con;
        // Getting database object
        this.database = CBDatabase.getInstance(con);
        // Getting documentation presenter reference
        this.docPresenter = DocumentationPresenter.getInstance(con);
        // Getting parent documentation
        this.parentDoc = docPresenter.getDocumentationById(docId);

        // Check if is measurement saved in parent documentation
        if (parentDoc.measurementList.isEmpty()) {
            //  We need to get data from database
            Log.i(TAG, "Get data from database");
            measurementList = database.getMeasurements(docId);
            parentDoc.measurementList = measurementList;
        } else {
            //Data are already in documentation's measurement list.
            measurementList = parentDoc.measurementList;
            Log.i(TAG, "Get data from parent documentation");
        }
        //Add presenter instance for future use
        listOfObject.add(this);
    }


    /**
     * This method return list of measurement names
     *
     * @return List of requested measurement names
     */
    @Override
    public ArrayList<String> getNameList() {
        ArrayList<String> list = new ArrayList<String>();

        for (Measurement d : measurementList) {
            list.add(d.getDate() + " - " + d.getTitle());
        }

        return list;
    }

    /**
     * This method return measurement id by measurement title
     *
     * @param title measurement title
     * @return measurement id
     */
    @Override
    public String getIdByTitle(String title) {
        String id = "";
        String newTitle = "";
        for (Measurement d : measurementList) {
            newTitle = d.getDate() + " - " + d.getTitle();
            if (newTitle.equals(title)) {
                id = d.getId();
                break;
            }
        }

        return id;
    }

    /**
     * This method return title of activity
     *
     * @return activity title
     */
    @Override
    public String getName() {
        String name = "";
        name = this.parentDoc.getTitle();

        return name;
    }

    /**
     * This method delete measurement by title
     *
     * @param title title of deleting measurement
     * @return true if is measurement successfully deleted
     */
    @Override
    public boolean deleteItem(String title) {
        String id = this.getIdByTitle(title);

        Measurement deletedMeas;

        for (int i = 0; i < this.measurementList.size(); i++) {
            if (this.measurementList.get(i).getId().equals(id)) {
                deletedMeas = this.measurementList.remove(i);
                return this.database.deleteItem(deletedMeas);
            }
        }
        return false;
    }


    /**
     * This method create new measurement.
     *
     * @param title Name of new measurement
     * @return return true if is new measurement successfully saved in database
     */
    @Override
    public boolean newMeasurement(String title) {

        //  Test loop if already measurement with same title exist
        for (Measurement d : measurementList) {
            if (d.getTitle().equals(title)) {
                Toast.makeText(this.appContext, "This measurement title already exist!", Toast.LENGTH_SHORT).show();
                Log.e(TAG, "User try to save duplicate measurement");
                return false;
            }
        }

        String newId = "";
        HashMap<String, Object> data = this.parentDoc.getNewMeasData();
        HashMap<String, Object> protocol = this.parentDoc.getNewMeasProtocol();
        HashMap<String, Object> objectModel = this.parentDoc.getNewMeasObjectModel();

        // Getting actual date;
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm");
        Date actualDate = new Date();

        // Creating new measurement instance
        Measurement newMeas = new Measurement(newId, this.parentDoc.getId(), title, dateFormat.format(actualDate), data, protocol, objectModel);

        // Saving instance into database and get id of this measurement from database
        newId = this.database.saveItem(newMeas);

        // Test if is not documentation successfully created
        if (newId == "") {
            return false;
        }

        // Set id from database
        newMeas.setId(newId);

        // Add into measurement list of presenter
        this.measurementList.add(newMeas);
        // Add into measurement list of parent documentation
        this.parentDoc.measurementList.add(newMeas);


        return true;
    }

    /**
     * This method create data layout for  New Measurement Activity.
     *
     * @param context  Application context
     * @param activity New Measurement activity for callback functions.
     * @return LinearLayout of data part of layout
     */
    @Override
    public LinearLayout getDataLayout(Context context, NewMeasurementActivity activity) {
        // get data layout from parent documentation
        LinearLayout l = this.parentDoc.createDataLayout(context, activity);

        if (l == null) {
            Log.e(TAG, "Data layout is null");
        }

        return l;
    }

    /**
     * This method create protocol layout for  New Measurement Activity.
     *
     * @param context Application context
     * @return LinearLayout of protocol part of layout
     */
    @Override
    public LinearLayout getProtocolLayout(Context context) {
        // get protocol layout from parent documentation
        LinearLayout l = this.parentDoc.createProtocolLayout(context);
        if (l == null) {
            Log.e(TAG, "Protocol layout is null");
        }

        return l;
    }

    /**
     * This method create properties layout for  New Measurement Activity.
     *
     * @param context        Application context
     * @param dataLayout     data layout
     * @param protocolLayout protocol layout
     * @param activity       New Measurement activity for callback functions.
     * @return
     */
    @Override
    public LinearLayout getPropertiesLayout(Context context, LinearLayout dataLayout, LinearLayout protocolLayout, NewMeasurementActivity activity) {
        LinearLayout l = this.parentDoc.createPropertiesLayout(context, activity);
        if (l == null) {
            Log.e(TAG, "Protocol layout is null");
        }

        return l;
    }

    /**
     * This method return title of new measurement activity
     *
     * @return
     */
    @Override
    public String getNewMeasureTitle() {
        String title;
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm");
        Date actualDate = new Date();
        title = "New measurement - " + dateFormat.format(actualDate);

        return title;
    }

    /**
     * This method return detail data information of measurement by measurement id.
     *
     * @param measId Measurement id
     * @return HashMap with detail data information
     */
    @Override
    public HashMap<String, Object> getDetailData(String measId) {
        for (Measurement m : this.measurementList) {
            if (m.getId().equals(measId)) {
                return m.getData();
            }
        }

        return new HashMap<String, Object>();
    }

    /**
     * This method return detail protocol information of measurement by measurement id.
     *
     * @param measId Measurement id
     * @return HashMap with detail protocol information
     */
    @Override
    public HashMap<String, Object> getDetailProtocol(String measId) {
        for (Measurement m : this.measurementList) {
            if (m.getId().equals(measId)) {
                return m.getProtocol();
            }
        }

        return new HashMap<String, Object>();
    }


    /**
     * Factory method for getting existing instance of presenter by activities.
     *
     * @param docId parent documentation id
     * @return existing Measurement presenter instance
     */
    public static MeasurementPresenter getInstanceByDocID(String docId) {

        for (MeasurementPresenter p : listOfObject) {
            if (p.parentDoc.getId().equals(docId)) {
                return p;
            }
        }

        return null;
    }

    /**
     * Get measurement name by id
     *
     * @param measId Measurement id
     * @return Meaurement name
     */
    @Override
    public String getMeasureName(String measId) {
        String name = "";

        for (Measurement m : this.measurementList) {
            if (m.getId().equals(measId)) {
                name = m.getMeasurementName();
                break;
            }
        }

        return name;
    }

}
