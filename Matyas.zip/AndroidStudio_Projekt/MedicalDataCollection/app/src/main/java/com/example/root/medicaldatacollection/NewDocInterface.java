package com.example.root.medicaldatacollection;

import java.util.ArrayList;

/**
 * This interface provide communication between New documentation activity and documentation presenter
 *
 * Created by matyasj on 2.3.16.
 *
 * @author Jiri Matyas
 * @version 1.0
 */
public interface NewDocInterface {

    /**
     * This method create new documentation. If is creating successful presenter return true to
     * activity. This new item save into database.
     *
     * @param title             title of documentation
     * @param archetypeFileName name of archetype name
     * @param type              type of documentation
     * @return true when is saving successful
     */
    boolean newDocumentation(String title, String archetypeFileName, String type);

    /**
     * This method return all archetype names in archetype folder on SD card
     *
     * @return Array list of archetype names
     */
    ArrayList<String> getArchetypeFiles();

    /**
     * This method return Array list of all documentation types
     *
     * @return Array list of documentation types
     */
    ArrayList<String> getDocTypeNames();
}
