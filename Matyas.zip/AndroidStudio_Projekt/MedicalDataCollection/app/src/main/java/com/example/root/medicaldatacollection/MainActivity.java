package com.example.root.medicaldatacollection;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * This class represent entry activity of this application. View of this activity is what user
 * firstly will see when start this application.
 *
 * Created by matyasj on 1.3.16.
 *
 * @author Jiri Matyas
 * @version 1.1
 */
public class MainActivity extends ActionBarActivity {
    /** Documentation presenter */
    private Presentable presenter;
    /** Button for creating New Documentation activity */
    private Button newDocButton;
    /** List of documentation */
    private ListView documentationList;
    /** Array adapter for list of documentaiton */
    private ArrayAdapter<String> documentationListAdapter;

    /** Tag for logging */
    public static final String TAG = "MAIN_ACTIVITY";

    /**
     * Method which is call when is this activity creating.
     *
     * @param savedInstanceState saved state of activity in their lifecycle
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        PreferenceManager.setDefaultValues(this, R.xml.preferences, false);

        this.presenter = DocumentationPresenter.getInstance(getApplicationContext());

        this.setTitle(presenter.getName());
        this.newDocButton = (Button) findViewById(R.id.newDocButton);
        this.documentationList = (ListView) findViewById(R.id.documentationsList);

        setNewDocListener(this.newDocButton);

        setDocumentationsList();
    }

    /**
     * This method create Menu bar from XML file (menu_main.xml)
     *
     * @param menu Action menu bar
     * @return true when is menu successfully created
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    /**
     * This method handle action menu bar clicks
     *
     * @param item Selected item
     * @return true when the menu item was successfully handled
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // The action bar will automatically handle clicks on the
        // Home/Up button, so long as you specify a parent activity
        // in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            // Start of settings activity
            Intent intent = new Intent();
            intent.setClass(getApplicationContext(), SettingsActivity.class);
            startActivity(intent);
            return true;
        }else if(id == R.id.action_close){
            // End of application
            Toast toast = Toast.makeText(getApplicationContext(), "Bye", Toast.LENGTH_SHORT);
            toast.show();

            finish();

            return true;
        }

        //  if nothing returned send to parent method
        return super.onOptionsItemSelected(item);
    }


    /**
     * When resume this activity have to create documentation list again.
     * New documentation can by created.
     *
     */
    @Override
    public void onResume() {
        super.onResume();
        //  Create Documentation list again.
        setDocumentationsList();
    }

    /**
     * This method create documentation list.
     *
     */
    private void setDocumentationsList() {
        // Get list of name from presenter. On this layer (Presentation) we work only
        // with documentation name strings.
        ArrayList<String> names = presenter.getNameList();
        // New Array adapter for documentation list.
        documentationListAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, names);
        // Setting adapter
        documentationList.setAdapter(documentationListAdapter);

        documentationList.setClickable(true);

        // set up Documentation list click listener
        documentationList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // When is clicked on some documentation new intent object will be created
                Intent intent = new Intent();
                // get name of chosen documentation
                String chosen = documentationList.getItemAtPosition(position).toString();
                // Set up class of Measurement list activity
                intent.setClass(getApplicationContext(), MeasurementListActivity.class);
                // put information which documentation was selected for Measurement list activity
                intent.putExtra("documentation_id", presenter.getIdByTitle(chosen));
                // Start new activity
                startActivity(intent);
            }
        });

        // Set up deleting listener to long click on documentation name.
        documentationList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

            public boolean onItemLongClick(AdapterView<?> arg0, View v, int position, long arg3) {
                // Get chosen documentation name
                String chosen = documentationList.getItemAtPosition(position).toString();
                // Pop up deleting alert for user accept.
                popUpAlert(chosen);
                return true;
            }
        });

    }

    /**
     * Set up listener to button for creating new documentation
     *
     * @param newDocButton Button for creating new documentation activity
     */
    private void setNewDocListener(final Button newDocButton){
        newDocButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Create new intent object for start New Documentation Activity
                Intent intent = new Intent();
                intent.setClass(getApplicationContext(), NewDocumentationActivity.class);
                startActivity(intent);
            }
        });
    }

    /**
     * This method pop up deleting alert for warning user before delete documentation with all
     * measurements which belongs.
     *
     * @param chosen Name of chosen documentation
     */
    private void popUpAlert(final String chosen){
        // Create alert dialog builder for warn user before deleting documentation
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        // Set up builder
        builder.setMessage("Are you sure you want to delete this documentation and all measurement which belongs?")
                .setTitle("Delete Documentation")
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    // When Yes button was clicked
                    public void onClick(DialogInterface dialog, int id) {
                        if(presenter.deleteItem(chosen)){
                            documentationListAdapter.remove(chosen);
                            documentationListAdapter.notifyDataSetChanged();
                            Toast.makeText(getApplicationContext(), "Documentation " + chosen + " has been deleted!",Toast.LENGTH_SHORT).show();
                        }

                    }
                });

        // Show pop up alert
        builder.create().show();
    }
}
