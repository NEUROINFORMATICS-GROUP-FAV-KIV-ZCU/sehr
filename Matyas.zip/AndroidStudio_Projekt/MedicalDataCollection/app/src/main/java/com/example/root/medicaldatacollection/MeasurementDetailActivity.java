package com.example.root.medicaldatacollection;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * This class representing activity which provide measurement detail view.
 * This view show detail information about chosen measurement.
 *
 * Created by matyasj on 2.3.16.
 *
 * @author Jiri Matyas
 * @version 1.0
 */
public class MeasurementDetailActivity extends ActionBarActivity {
    /**
     * Id of documentation of measurement which this activity show
     */
    private String docId;
    /*  Id of measurement which this activity show*/
    private String measId;
    /**
     * Measurement presenter
     */
    private MeasDetailInterface presenter;
    /**
     * Measurement data part of information layout
     */
    private LinearLayout dataLayout;
    /**
     * Measurement protocol part of information layout
     */
    private LinearLayout protocolLayout;

    /**
     * TAG for logging
     */
    public static final String TAG = "DETAIL_MEAS_ACTIVITY";


    /**
     * Method which is call when is this activity creating.
     *
     * @param savedInstanceState saved state of activity in their lifecycle
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_detail);

        Intent intent = getIntent();

        init(intent);
    }

    /**
     * This method create Menu bar from XML file (menu_main.xml)
     *
     * @param menu Action menu bar
     * @return true when is menu successfully created
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_secondary, menu);
        return true;
    }


    /**
     * This method handle action menu bar clicks
     *
     * @param item Selected item
     * @return true when the menu item was successfully handled
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();


        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            // Start of settings activity
            Intent intent = new Intent();
            intent.setClass(getApplicationContext(), SettingsActivity.class);
            startActivity(intent);
            return true;
        } else if (id == R.id.action_back) {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * This method print data part of measurement information.
     *
     * @param data HashMap of data part of information
     */
    public void printData(HashMap<String, Object> data) {
        Set set = data.entrySet();

        Iterator i = set.iterator();

        // In this textview will be information
        TextView text;

        // Loop which is able to go throw HashMap by Iterator
        while (i.hasNext()) {
            text = new TextView(this);
            Map.Entry item = (Map.Entry) i.next();

            text.setText(item.getKey() + ": " + item.getValue());
            // Add line into layout
            this.dataLayout.addView(text);
        }
    }

    /**
     * This method print protocol part of measurement information.
     *
     * @param protocol HashMap of protocol part of information
     */
    public void printProtocol(HashMap<String, Object> protocol) {
        Set set = protocol.entrySet();

        Iterator i = set.iterator();

        // In this textview will be information
        TextView text;

        // Loop which is able to go throw HashMap by Iterator
        while (i.hasNext()) {
            text = new TextView(this);
            Map.Entry item = (Map.Entry) i.next();

            text.setText(item.getKey() + ": " + item.getValue());
            // Add line into layout
            this.protocolLayout.addView(text);
        }
    }

    /**
     * Initialization method for setting up activity
     *
     * @param intent Intent object for getting input parameters
     */
    public void init(Intent intent) {
        // Get documentation id
        this.docId = intent.getStringExtra("documentation_id");
        // Get measurement id
        this.measId = intent.getStringExtra("measurement_id");
        // Get measurement presenter
        this.presenter = MeasurementPresenter.getInstanceByDocID(docId);

        // Get protocol and data layout from view
        this.protocolLayout = (LinearLayout) findViewById(R.id.Protocol);
        this.dataLayout = (LinearLayout) findViewById(R.id.Data);
        // Set Title of activity
        this.setTitle(presenter.getMeasureName(measId));

        // Get data and protocol information from presenter
        HashMap<String, Object> data = presenter.getDetailData(measId);
        HashMap<String, Object> protocol = presenter.getDetailProtocol(measId);

        // call method for printing data part of measurement information
        printData(data);
        // call method for printing protocol part of measurement information
        printProtocol(protocol);
    }

}
