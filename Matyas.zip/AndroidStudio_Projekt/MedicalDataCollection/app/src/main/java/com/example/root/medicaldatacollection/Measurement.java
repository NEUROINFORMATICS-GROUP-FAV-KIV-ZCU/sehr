package com.example.root.medicaldatacollection;

import com.couchbase.lite.Document;

import java.util.HashMap;

/**
 * This class represent every measurement from some documentation
 * <p/>
 * Created by matyasj on 28.2.16.
 *
 * @author Jiri Matyas
 * @version 1.0
 */
public class Measurement extends Element {
    /**
     * Date and time of creating measurement
     */
    private String date;
    /**
     * Data part of object model of measurement
     */
    private HashMap<String, Object> data;
    /**
     * Protocol part of object model of measurement
     */
    private HashMap<String, Object> protocol;
    /**
     * Object model of measurement
     */
    private HashMap<String, Object> objectModel;
    /**
     * Id of parent documentation
     */
    private String documentationId;


    /**
     * Constructor of measurement.
     *
     * @param id          Measurement id
     * @param docId       Parent documentation id
     * @param title       Measurement title
     * @param date        Date and time of creating measurement
     * @param data        Data part of object model of measurement
     * @param protocol    Protocol part of object model of measurement
     * @param objectModel Object model of measurement
     */
    public Measurement(String id, String docId, String title, String date, HashMap<String, Object> data, HashMap<String, Object> protocol, HashMap<String, Object> objectModel) {
        super(id, title);
        this.date = date;
        this.data = data;
        this.protocol = protocol;
        this.objectModel = objectModel;

        this.documentationId = docId;
    }

    /**
     * Date setter
     *
     * @return Measurement date
     */
    public String getDate() {
        return date;
    }

    /**
     * Parent documentation id setter
     *
     * @return Documentation id
     */
    public String getDocumentationId() {
        return documentationId;
    }

    /**
     * Data setter
     *
     * @return HashMap with data
     */
    public HashMap<String, Object> getData() {
        return data;
    }

    /**
     * Data setter
     *
     * @return HashMap with data
     */
    public HashMap<String, Object> getProtocol() {
        return protocol;
    }

    /**
     * Object model setter
     *
     * @return HashMap with object model
     */
    public HashMap<String, Object> getObjectModel() {
        return objectModel;
    }

    /**
     * Measurement name getter
     *
     * @return Measurement name
     */
    public String getMeasurementName() {
        return this.getTitle() + " - " + this.getDate();
    }

    /**
     * This method create map representation of measurement for save into database
     *
     * @return HashMap map representation
     */
    public HashMap<String, Object> getMapRepresentation() {
        HashMap<String, Object> map = new HashMap<String, Object>();

        map.put("documentation_id", this.getDocumentationId());
        map.put("title", this.getTitle());
        map.put("date", this.getDate());
        map.put("data", this.getData());
        map.put("protocol", this.getProtocol());
        map.put("object_model", this.getObjectModel());

        return map;
    }

    /**
     * Factory method for creating Measurement instance from database document
     *
     * @param doc Database document
     * @return Measurement object
     */
    public static Measurement getObjectByDocument(Document doc) {
        Measurement newMeas = null;

        String documentationId = (String) doc.getProperty("documentation_id");
        String title = (String) doc.getProperty("title");
        String date = (String) doc.getProperty("date");
        HashMap<String, Object> data = (HashMap<String, Object>) doc.getProperty("data");
        HashMap<String, Object> protocol = (HashMap<String, Object>) doc.getProperty("protocol");
        HashMap<String, Object> objectModel = (HashMap<String, Object>) doc.getProperty("object_model");

        newMeas = new Measurement(doc.getId(), documentationId, title, date, data, protocol, objectModel);

        return newMeas;
    }

}
