package com.example.root.medicaldatacollection;


import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.EditTextPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;

/**
 * This is Application settings class. This activity provides View for set up application attributes.
 * <p/>
 * Created by matyasj on 14.4.16.
 *
 * @author Jiri Matyas
 * @version 1.0
 */
public class SettingsActivity extends PreferenceActivity {
    /**
     * Synchronization setting
     */
    private CheckBoxPreference isSynchronizationTime;
    /**
     * Synchronization server andres setting
     */
    private EditTextPreference serverURL;

    /**
     * Method which is call when is this activity creating.
     *
     * @param savedInstanceState saved state of activity in their lifecycle
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.preferences);
        init();
    }

    /**
     * Initialization of settings activity
     */
    private void init() {
        //Set up check box for synchroniyation
        isSynchronizationTime = (CheckBoxPreference) findPreference("applicationSync");

        isSynchronizationTime.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {

            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                if (newValue.toString().equals("true")) {
                    CBDatabase.getInstance(getApplicationContext()).synchronization(true);
                } else {
                    CBDatabase.getInstance(getApplicationContext()).synchronization(false);
                }
                return true;


            }
        });

        // Set up server address
        serverURL = (EditTextPreference) findPreference("remote_server_url");

        serverURL.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                CBDatabase.getInstance(getApplicationContext()).createReplication();
                return true;
            }
        });

    }

}
