package modules.sleepAsAndroid;


import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Build;
import android.os.Environment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.root.medicaldatacollection.Modulable;
import com.example.root.medicaldatacollection.NewMeasurementActivity;
import com.example.root.medicaldatacollection.R;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * This class is an Entry point of SleepAsAndroid module. Object of this class create templates for
 * data and protocol part of New Measurement View. Data from this templates can get and return as
 * HashMap object which is commutable for JSON format. Object can also get Object model from
 * SleepAsAndroidMeasurement object.
 *
 * Created by root on 17.3.16.
 * @author Jiri Matyas
 * @version 1.0
 */
public class SleepAsAndroidModule implements Modulable {
    /**
     * SD card directory on mobile device
     */
    private File sdCard;
    /**
     * SleepAsAndroid exported file
     */
    private File exportFile;
    /**
     * Reader for reading from exported file
     */
    private BufferedReader br;
    /**
     * Measurement exported from SleepAsAndroid in file
     */
    private ArrayList<SleepAsAndroidMeasurement> measurements;

    /**
     * Data layout
     */
    private LinearLayout dataLayout;
    /**
     * Protocol layout
     */
    private LinearLayout protocolLayout;

    /**
     * Data components
     */
    private EditText measFromText;
    private EditText measToText;
    private EditText comment;
    private EditText sleepDurationText;
    private Spinner measSpinner;

    /**
     * Protocol components
     */
    private EditText deviceText;
    private Spinner devicePositionSpinner;
    private EditText calculationMethod;

    /**
     * Actual selected SleepAsAndroid measurement
     */
    private int selectedMeasurement;


    /**
     * Device position definition
     */
    public static String[] devicePositions;
    /**
     * SleepAsAndroid export folder name
     */
    public static final String SLEEP_DATA_SD_FOLDER_NAME = "sleep-data";
    /**
     * SleepAsAndroid export file name
     */
    public static String SLEEP_DATA_FILE = "sleep-export.csv";
    /**
     * Tag for logging
     */
    public static final String TAG = "SleepAsAndroidModule";

    /**
     * SleepAsAndroid module constructor. Objects of this class take care about SleepAsAndroid sleep
     * measurements in export file.
     */
    public SleepAsAndroidModule() {
        /** Initialization of measurement Array list */
        this.measurements = new ArrayList<SleepAsAndroidMeasurement>();
        /** Get SD card folder */
        this.sdCard = Environment.getExternalStorageDirectory();
        /** Get SleepAsAndroid export file*/
        this.exportFile = new File(sdCard + File.separator + SLEEP_DATA_SD_FOLDER_NAME + File.separator + SLEEP_DATA_FILE);

        /*  Test if exist exported file on SD card*/
        if (exportFile.exists()) {
            readSleepDataFromFile(exportFile);
        }
        /** Select the last measurement */
        this.selectedMeasurement = this.measurements.size() - 1;
    }

    /**
     * Get data from data part of New Measurement view.
     *
     * @return HashMap with data
     */
    @Override
    public HashMap<String, Object> getData() {
        HashMap<String, Object> data = new HashMap<String, Object>();
        data.put("Measure from", measurements.get(selectedMeasurement).getMeasureFrom());
        data.put("Measure to", measurements.get(selectedMeasurement).getMeasureTo());
        data.put("Sleep duration", measurements.get(selectedMeasurement).getSleepDuration());
        data.put("Comment", measurements.get(selectedMeasurement).getComment());

        Log.e(TAG, "Comment: " + comment.getText());

        return data;
    }

    /**
     * Get data from protocol part of New Measurement view.
     *
     * @return HashMap with data
     */
    @Override
    public HashMap<String, Object> getProtocol() {
        HashMap<String, Object> protocol = new HashMap<String, Object>();
        protocol.put("Device", measurements.get(selectedMeasurement).getDeviceName());
        protocol.put("Device position", measurements.get(selectedMeasurement).getDevicePosition());
        protocol.put("Calculating method", "Sleep As Android");


        return protocol;
    }

    /**
     * Get Object model from selected SleepAsAndroid measurement object.
     *
     * @return HashMap representing object model of selected measurement.
     */
    @Override
    public HashMap<String, Object> getObjectModel() {
        HashMap<String, Object> objectModel = measurements.get(selectedMeasurement).getObjectModel();

        return objectModel;
    }

    /**
     * Read sleep data from SleepAsAndroid export file.
     *
     * @param file Exported file on SD card
     * @return true when is reading successfully, false otherwise.
     */
    public boolean readSleepDataFromFile(File file) {
        try {
            Log.e(TAG, "File: " + file.getAbsolutePath());
            br = new BufferedReader(new FileReader(file));
            String line, metaData, data;

            // File parsing.
            while ((line = br.readLine()) != null) {
                if (line.contains("Comment")) {
                    // In every first line are always metadata
                    metaData = line;
                    metaData = metaData.replace("\"", "");

                    line = br.readLine();

                    // In every first line are always data
                    data = line;
                    data = data.replace("\"", "");

                    SleepAsAndroidMeasurement newMeasurement = new SleepAsAndroidMeasurement(metaData, data);

                    this.measurements.add(newMeasurement);
                }
            }
            // Close stream
            br.close();
        } catch (IOException e) {
            Log.e(TAG, "File can not be read!");
            return false;
        }
        return true;
    }

    /**
     * Get Name of module.
     *
     * @return Module name
     */
    @Override
    public String toString() {
        return "Sleep As Android";
    }

    /**
     * Create layout of data part of New Measurement view.
     *
     * @param context Application context for creating components.
     * @return Linear layout of data part of view
     */
    @Override
    public LinearLayout getDataLayout(final Context context, NewMeasurementActivity activity) {
        dataLayout = new LinearLayout(context);

        dataLayout.setBackgroundColor(Color.GRAY);
        dataLayout.setOrientation(LinearLayout.VERTICAL);

        measFromText = new EditText(context);
        measToText = new EditText(context);
        comment = new EditText(context);

        //Measurement from export file
        measSpinner = new Spinner(context);
        ArrayAdapter<SleepAsAndroidMeasurement> adapter;
        adapter = new ArrayAdapter<SleepAsAndroidMeasurement>(context, android.R.layout.simple_spinner_item, this.measurements);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        measSpinner.setAdapter(adapter);
        measSpinner.setSelection(selectedMeasurement);

        setMeasurementSpinnerListener(measSpinner, context, activity);

        LinearLayout measurementField = getField("Exported measurement", measSpinner, context);

        dataLayout.addView(measurementField);

        //  Measure From
        measFromText.setText(measurements.get(selectedMeasurement).getMeasureFrom());
        measFromText.setEnabled(false);

        LinearLayout sleepMeasFromField = getField("Measure from", measFromText, context);

        dataLayout.addView(sleepMeasFromField);

        measToText.setText(measurements.get(selectedMeasurement).getMeasureTo());
        measToText.setEnabled(false);

        LinearLayout sleepMeasToField = getField("Measure to", measToText, context);

        dataLayout.addView(sleepMeasToField);

        //  Sleep Duration
        sleepDurationText = new EditText(context);


        sleepDurationText.setText(measurements.get(selectedMeasurement).getSleepDuration() + "h");

        sleepDurationText.setEnabled(false);
        LinearLayout sleepDurationField = getField("Sleep Duration", sleepDurationText, context);

        dataLayout.addView(sleepDurationField);

        comment.setText(measurements.get(selectedMeasurement).getComment());

        comment.addTextChangedListener(new TextWatcher() {
            // This two methods have to be implemented
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                // After comment change is set SleepAsAndroidMeasurement
                measurements.get(selectedMeasurement).setComment(s.toString());
                Log.i(TAG, "New comment" + measurements.get(selectedMeasurement).getComment());
            }
        });

        LinearLayout commentField = getField("Comment", comment, context);

        dataLayout.addView(commentField);

        return dataLayout;
    }

    /**
     * Create layout of protocol part of New Measurement view.
     *
     * @param context Application context for creating components.
     * @return Linear layout of data part of view
     */
    @Override
    public LinearLayout getProtocolLayout(Context context) {
        Resources res = context.getResources();
        devicePositions = res.getStringArray(R.array.device_position);
        JSONObject json = new JSONObject();

        // Protocol layout set up
        protocolLayout = new LinearLayout(context);
        protocolLayout.setBackgroundColor(Color.GRAY);
        protocolLayout.setOrientation(LinearLayout.VERTICAL);

        // device name field set up
        deviceText = new EditText(context);
        deviceText.setText(Build.MANUFACTURER + " " + Build.PRODUCT);
        deviceText.setEnabled(false);
        LinearLayout deviceField = getField("Device", deviceText, context);
        protocolLayout.addView(deviceField);

        // device position field set up
        devicePositionSpinner = new Spinner(context);

        // Set up device position adapter
        ArrayAdapter<String> adapter;

        adapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, devicePositions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        devicePositionSpinner.setAdapter(adapter);

        // Device position spinner listener set up
        devicePositionSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                measurements.get(selectedMeasurement).setDevicePosition(devicePositions[position]);
                Log.i(TAG, "New measurement position: " + devicePositions[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        LinearLayout devicePositionField = getField("Device position", devicePositionSpinner, context);

        protocolLayout.addView(devicePositionField);

        // Calculation method field set up
        calculationMethod = new EditText(context);
        calculationMethod.setText(measurements.get(selectedMeasurement).toString());
        calculationMethod.setEnabled(false);
        LinearLayout calculationMethodField = getField("Calculation method", calculationMethod, context);

        protocolLayout.addView(calculationMethodField);

        return protocolLayout;
    }

    /**
     * Create form field with name.
     *
     * @param title     name of field
     * @param component component in right part of field
     * @param context   application context for creating components
     * @return Field with name and component in right part of field.
     */
    private LinearLayout getField(String title, View component, Context context) {
        LinearLayout field = new LinearLayout(context);
        field.setOrientation(LinearLayout.HORIZONTAL);
        TextView label = new TextView(context);
        label.setText(title);
        field.addView(label, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        field.addView(component, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        return field;
    }


    /**
     * This method set up listener for Sleep As Android measurements spinner
     *
     * @param measSpinner Sleep As Android measurements spinner
     * @param context     Application context
     * @param activity    NewMewsurementactivity for callback when spinner choice is changed
     */
    public void setMeasurementSpinnerListener(Spinner measSpinner, final Context context, final NewMeasurementActivity activity) {
        measSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {

                if (selectedMeasurement != (id)) {
                    Log.i(TAG, "User choose measurement: " + measurements.get((int) id).toString());
                    selectedMeasurement = (int) id;
                    activity.setLayout(false);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                Log.i(TAG, "User choose nothing");
            }

        });
    }

    /**
     * Method for getting comment
     *
     * @return EditText field with comment
     */
    public EditText getComment() {
        return this.comment;
    }


}
