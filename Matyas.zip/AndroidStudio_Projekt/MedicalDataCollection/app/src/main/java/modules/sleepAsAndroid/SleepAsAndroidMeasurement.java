package modules.sleepAsAndroid;

import android.os.Build;

import java.util.HashMap;

/**
 * This class represent Sleep As Android measurement.
 * <p/>
 * Created by root on 21.3.16.
 *
 * @author Jiri Matyas
 * @version 1.0
 */
public class SleepAsAndroidMeasurement {
    /**
     * Id of measurement
     */
    private String id;
    /**
     * Date and time start of measurement
     */
    private String measureFrom;
    /**
     * Date and time end of measurement
     */
    private String measureTo;
    /**
     * Number of sleep hours
     */
    private String sleepDuration;
    /**
     * User comment of measurement
     */
    private String comment;
    /**
     * Time interval of measurement
     */
    private String timeInterval;
    /**
     * Frame rate of sleep movement sampling
     */
    private String frameRate;
    /**
     * Sleep frames of measurement
     */
    private HashMap<String, String> sleepFrames;
    /**
     * Device position during sleep
     */
    private String devicePosition;
    /**
     * Device name
     */
    private String deviceName;
    /**
     * Calculating method for classification sleep phase
     */
    private String calculatingMethod;
    /**
     * Object model sleep measurement
     */
    private HashMap<String, Object> objectModel;

    /**
     * TAG for logging
     */
    public static String TAG = "SLEEP AS ANDROID MEASUREMENT";

    /**
     * Sleep As Android measurement constructor
     *
     * @param metaData measurement metadata (every first line in export file)
     * @param data     mesurement metadata (every second line in export file)
     */
    public SleepAsAndroidMeasurement(String metaData, String data) {
        this.sleepFrames = new HashMap<String, String>();
        // Getting device name
        this.deviceName = Build.MANUFACTURER + " " + Build.PRODUCT;
        this.calculatingMethod = TAG;

        // File parsing
        //--------------------------------------------------
        metaData = metaData.replace("\"", "");
        data = data.replace("\"", "");

        String[] metaDataArray = metaData.split(",");
        String[] dataArray = data.split(",");

        for (int i = 0; i < metaDataArray.length; i++) {
            String token;
            token = metaDataArray[i];
            switch (token) {
                case "Id":
                    this.id = dataArray[i];
                    break;

                case "From":
                    this.measureFrom = dataArray[i];
                    break;

                case "To":
                    this.measureTo = dataArray[i];
                    break;

                case "Comment":
                    this.comment = dataArray[i];
                    break;

                case "Hours":
                    this.sleepDuration = dataArray[i];
                    break;
                case "Framerate":
                    this.frameRate = dataArray[i];
                    break;
                default:
                    if (metaDataArray[i].contains(":")) {
                        this.sleepFrames.put(metaDataArray[i], dataArray[i]);
                    }
                    break;
            }
        }
        //--------------------------------------------------

        // getting object model
        this.objectModel = createObjectModel();
    }

    /**
     * Id getter
     *
     * @return measurement ID
     */
    public String getId() {
        return id;
    }

    /**
     * Date and time start of measurement getter
     *
     * @return measurement Date and time start of measurement
     */
    public String getMeasureFrom() {
        return measureFrom;
    }

    /**
     * Date and time end of measurement getter
     *
     * @return measurement Date and time end of measurement
     */
    public String getMeasureTo() {
        return measureTo;
    }

    /**
     * Sleep duration getter
     *
     * @return measurement Sleep duration
     */
    public String getSleepDuration() {
        return sleepDuration;
    }

    /**
     * Comment getter
     *
     * @return comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * Device position getter
     *
     * @return Device position
     */
    public String getDevicePosition() {
        return devicePosition;
    }

    /**
     * Device name getter
     *
     * @return Device name
     */
    public String getDeviceName() {
        return deviceName;
    }

    /**
     * Time interval getter
     *
     * @return Time interval
     */
    public String getTimeInterval() {
        return timeInterval;
    }

    /**
     * Sleep frames getter
     *
     * @return Sleep frames HashMap
     */
    public HashMap<String, String> getSleepFrames() {
        return sleepFrames;
    }

    /**
     * Date and time start of sleep setter
     *
     * @param measureFrom Date and time start of sleep
     */
    public void setMeasureFrom(String measureFrom) {
        this.measureFrom = measureFrom;
    }

    /**
     * Date and time end of sleep setter
     *
     * @param measureTo Date and time end of sleep
     */
    public void setMeasureTo(String measureTo) {
        this.measureTo = measureTo;
    }

    /**
     * Sleep duration setter
     *
     * @param sleepDuration Sleep duration
     */
    public void setSleepDuration(String sleepDuration) {
        this.sleepDuration = sleepDuration;
    }

    /**
     * Comment setter
     *
     * @param comment Comment
     */
    public void setComment(String comment) {
        this.comment = comment;
    }

    /**
     * Device position setter
     *
     * @param devicePosition Device position
     */
    public void setDevicePosition(String devicePosition) {
        this.devicePosition = devicePosition;
    }

    /**
     * To string method
     *
     * @return String representing of this measurement
     */
    @Override
    public String toString() {
        return this.measureFrom;
    }

    /**
     * This method get object model
     *
     * @return HashMap reprezentation of object model
     */
    public HashMap<String, Object> getObjectModel() {
        return objectModel;
    }

    /**
     * This method create object model of Sleep As Android measurement.
     *
     * @return SleepObjectModel object model
     */
    public HashMap<String, Object> createObjectModel() {
        return new SleepObjectModel(measureFrom, measureTo, sleepDuration, comment, frameRate, sleepFrames, devicePosition, deviceName, calculatingMethod);
    }
}
