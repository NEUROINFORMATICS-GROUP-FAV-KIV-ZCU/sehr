package modules.sleepAsAndroid;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * This class represent Object Model of SleepASAndroid sleep measurement.
 * <p/>
 * Created by root on 23.3.16.
 */
public class SleepObjectModel extends HashMap<String, Object> {
    /**
     * There are codes of sleep attributes from sleep archetype.
     * Unfortunately it is not possible to get them from archetype by parser.
     */
    public static final String SLEEP_GLOBAL = "at0000";
    public static final String EVENT_SERIES = "at0001";
    public static final String ANY_EVENT = "at0002";
    public static final String TREE_CLUSTER = "at0003";
    public static final String DURATION_SLEEP = "at0004";
    public static final String MEASURED_FROM = "at0005";
    public static final String MEASURED_TO = "at0006";
    public static final String GLOBAL_SLEEP_PARAMETERS = "at0007";
    public static final String SLEEP = "at0008";
    public static final String TIME_INTERVAL = "at0009";
    public static final String NREM_1 = "at0010";
    public static final String NREM_2 = "at0011";
    public static final String NREM_3 = "at0012";
    public static final String NREM_4 = "at0013";
    public static final String COMMENT = "at0014";
    public static final String SLEEP_RECORDING = "at0015";
    public static final String TREE = "at0016";
    public static final String REM = "at0017";
    public static final String NREM = "at0018";
    public static final String DEVICE = "at0019";
    public static final String DEVICE_POSITION = "at0020";
    public static final String CALCULATION_METHOD = "at0021";


    /**
     * Object model constructor. Create filled HashMap object
     *
     * @param measureFrom       Date and time start of sleep monitoring.
     * @param measureTo         Date and time end of sleep monitoring.
     * @param sleepDuration     Number of hours during sleep.
     * @param comment           User comment.
     * @param frameRate         Time interval of movement sampling.
     * @param sleepFrames       HashMap of sleep samples.
     * @param devicePosition    Position of mobile device during sleep.
     * @param deviceName        Name and detail information about mobile device.
     * @param calculatingMethod Calculation method to decide in which sleep phase user is.
     */
    public SleepObjectModel(String measureFrom, String measureTo, String sleepDuration, String comment,
                            String frameRate, HashMap<String, String> sleepFrames, String devicePosition,
                            String deviceName, String calculatingMethod) {
        // Object model creation

        Map<String, Object> TREE16 = new HashMap<String, Object>();
        Map<String, Object> rem = new HashMap<String, Object>();
        Map<String, Object> nrem = new HashMap<String, Object>();
        Map<String, Object> nrem1 = new HashMap<String, Object>();
        Map<String, Object> nrem2 = new HashMap<String, Object>();
        Map<String, Object> nrem3 = new HashMap<String, Object>();
        Map<String, Object> nrem4 = new HashMap<String, Object>();
        Map<String, Object> sleep = new HashMap<String, Object>();
        Map<String, Object> sleepComplet = new HashMap<String, Object>();
        Map<String, Object> eventSeries = new HashMap<String, Object>();
        Map<String, Object> anyEvent = new HashMap<String, Object>();
        Map<String, Object> tree = new HashMap<String, Object>();
        Map<String, Object> globalSleepParameters = new HashMap<String, Object>();

        globalSleepParameters.put(MEASURED_FROM, measureFrom);
        globalSleepParameters.put(MEASURED_TO, measureTo);
        globalSleepParameters.put(COMMENT, comment);
        globalSleepParameters.put(SLEEP_RECORDING, "");
        globalSleepParameters.put(DURATION_SLEEP, sleepDuration);
        globalSleepParameters.put(TIME_INTERVAL, frameRate);

        // Sleep phase classification
        Iterator it = sleepFrames.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();

            double move = Double.parseDouble(pair.getValue().toString());
            String time = (String) pair.getKey();


            if (move == -0.001) {
                nrem4.put(time, move);
            } else if (move > 0 && move < 0.5) {
                nrem3.put(time, move);
            } else if (move > 0.5 && move < 1.5) {
                nrem2.put(time, move);
            } else {
                nrem1.put(time, move);
            }
            it.remove(); // avoids a ConcurrentModificationException
        }

        nrem.put(NREM_1, nrem1);
        nrem.put(NREM_2, nrem2);
        nrem.put(NREM_3, nrem3);
        nrem.put(NREM_4, nrem4);

        //Sleep data
        sleep.put(REM, rem);
        sleep.put(NREM, nrem);

        //Sleep tree
        tree.put(GLOBAL_SLEEP_PARAMETERS, globalSleepParameters);
        tree.put(SLEEP, sleep);

        //Archetype wrappers
        anyEvent.put(TREE_CLUSTER, tree);
        eventSeries.put(ANY_EVENT, anyEvent);
        sleepComplet.put(EVENT_SERIES, eventSeries);

        //Whole tree
        TREE16.put(DEVICE, deviceName);
        TREE16.put(DEVICE_POSITION, devicePosition);
        TREE16.put(CALCULATION_METHOD, calculatingMethod);
        sleepComplet.put(TREE, TREE16);

        this.put(SLEEP_GLOBAL, sleepComplet);
    }


}
