package com.example.root.medicaldatacollection;

import android.test.InstrumentationTestCase;

import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;

/**
 * This class provide Measurement getting map representation test.
 * <p/>
 * Created by root on 25.4.16.
 *
 * @author Jiri Matyas
 * @version 1.0
 */
public class MeasurementTest extends InstrumentationTestCase {
    Measurement first;
    String firstMapRepresentation = "{protocol={Protocol4=Value5, Protocol3=Value3, Protocol2=Value1, Protocol1=Value2, Protocol5=Value6}, date=12.10.2016, documentation_id=docidasdfjioasdfj, title=title, object_model={Object5=Value6, Object4=Value5, Object2=Value1, Object1=Value2, Object3=Value3}, data={Data4=Value3, Data5=Value4, Data2=Value2, Data3=Value1, Data1=Value1}}";

    @Before
    public void setUp(){
        HashMap<String, Object> data1 = new HashMap<String, Object>();
        HashMap<String, Object> prot1 = new HashMap<String, Object>();
        HashMap<String, Object> objectModel = new HashMap<String, Object>();

        data1.put("Data1","Value1");
        data1.put("Data2","Value2");
        data1.put("Data3","Value1");
        data1.put("Data4","Value3");
        data1.put("Data5","Value4");

        prot1.put("Protocol1","Value2");
        prot1.put("Protocol2","Value1");
        prot1.put("Protocol3","Value3");
        prot1.put("Protocol4","Value5");
        prot1.put("Protocol5","Value6");

        objectModel.put("Object1","Value2");
        objectModel.put("Object2","Value1");
        objectModel.put("Object3","Value3");
        objectModel.put("Object4","Value5");
        objectModel.put("Object5","Value6");

        first = new Measurement("id1", "docidasdfjioasdfj","title", "12.10.2016", data1, prot1, objectModel);
    }


    @Test
    public void testGetMapRepresentation() throws Exception {
        String result = first.getMapRepresentation().toString();
        assertTrue(result.equals(firstMapRepresentation));
    }
}