package com.example.root.medicaldatacollection;

import android.test.InstrumentationTestCase;

import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;

import modules.sleepAsAndroid.SleepAsAndroidMeasurement;

/**
 * This class provide SleepAsAndroidMesurement getting object model tests.
 * <p/>
 * Created by root on 25.4.16.
 *
 * @author Jiri Matyas
 * @version 1.0
 */
public class SleepAsAndroidTest extends InstrumentationTestCase{
    SleepAsAndroidMeasurement firstSleepMeasurement;
    SleepAsAndroidMeasurement secondSleepMeasurement;
    SleepAsAndroidMeasurement thirdSleepMeasurement;

    String firstTestMetaData = "Id,Tz,From,To,Sched,Hours,Rating,Comment,Framerate,Snore,Noise,Cycles,DeepSleep,LenAdjust,Geo,23:39,23:44,23:49,23:54,23:59,0:04,0:09,0:14,0:19,0:24,0:29,0:34,0:39,0:44,0:49,0:54,0:59,1:04,1:09,1:14,1:19,1:24,1:29,1:34,1:39,1:44,1:49,1:54,1:59,2:04,2:09,2:14,2:19,2:24,2:29,2:34,2:39,2:44,2:49,2:54,2:59,3:04,3:09,3:14,3:19,3:24,3:29,3:34,3:39,3:44,3:49,3:54,3:59,4:05,4:10,4:15,4:20,4:25,4:30,4:35,4:40,4:45,4:50,4:55,5:00,5:05,5:10,5:15,5:20,5:25,5:30,5:35,5:40,5:45,5:50,5:55,6:00,6:05,6:10,6:15,6:20,6:25,6:30,6:35,6:40,6:45,6:50,6:55,7:00,Event,Event,Event,Event,Event,Event,Event,Event";
    String firstTestData = "1415054064353,Europe/Sarajevo,03. 11. 2014 23:34,04. 11. 2014 7:00,16. 11. 2014 0:14,7.430,0.0, #home,10000,-1,0.012298567,-1,-1.0,0,e069ca2,2.5852635,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,0.0,0.0,1.0524253,1.0526887,0.7676697,0.73896027,0.7387359,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,BROKEN_START-1415054365019,BROKEN_END-1415076313637,LOW_BATTERY-1415078238758,BROKEN_START-1415078418299,ALARM_EARLIEST-1415079600000,BROKEN_END-1415080823702,TRACKING_STOPPED_BY_USER-1415080823703,ALARM_LATEST-1415081400000";
    String firstTestObjectModel = "{at0000={at0001={at0002={at0003={at0007={at0009=10000, at0014= #home, at0015=, at0004=7.430, at0005=03. 11. 2014 23:34, at0006=04. 11. 2014 7:00}, at0008={at0018={at0012={}, at0011={6:20=0.7387359, 6:00=1.0524253, 6:05=1.0526887, 6:10=0.7676697, 6:15=0.73896027}, at0010={23:39=2.5852635, 5:55=0.0, 5:50=0.0}, at0013={3:44=-0.001, 4:40=-0.001, 0:34=-0.001, 2:09=-0.001, 3:34=-0.001, 2:19=-0.001, 3:24=-0.001, 4:25=-0.001, 6:50=-0.001, 4:15=-0.001, 4:10=-0.001, 6:35=-0.001, 0:19=-0.001, 0:44=-0.001, 2:34=-0.001, 2:14=-0.001, 5:15=-0.001, 5:30=-0.001, 2:59=-0.001, 6:25=-0.001, 6:45=-0.001, 0:04=-0.001, 0:14=-0.001, 6:55=-0.001, 1:24=-0.001, 4:45=-0.001, 5:20=-0.001, 2:29=-0.001, 3:49=-0.001, 3:59=-0.001, 0:09=-0.001, 1:04=-0.001, 2:04=-0.001, 2:54=-0.001, 4:05=-0.001, 4:30=-0.001, 1:49=-0.001, 3:54=-0.001, 0:59=-0.001, 1:29=-0.001, 2:39=-0.001, 23:54=-0.001, 3:04=-0.001, 1:19=-0.001, 5:10=-0.001, 1:34=-0.001, 5:35=-0.001, 1:54=-0.001, 3:09=-0.001, 4:20=-0.001, 4:55=-0.001, 0:29=-0.001, 2:24=-0.001, 2:44=-0.001, 3:39=-0.001, 1:09=-0.001, 23:44=-0.001, 5:05=-0.001, 7:00=-0.001, 3:29=-0.001, 4:35=-0.001, 3:14=-0.001, 6:30=-0.001, 6:40=-0.001, 2:49=-0.001, 4:50=-0.001, 5:40=-0.001, 23:49=-0.001, 5:00=-0.001, 0:39=-0.001, 23:59=-0.001, 5:25=-0.001, 3:19=-0.001, 0:54=-0.001, 1:59=-0.001, 1:14=-0.001, 1:44=-0.001, 0:24=-0.001, 5:45=-0.001, 0:49=-0.001, 1:39=-0.001}}, at0017={}}}}}, at0016={at0019=unknown sdk_google_phone_x86, at0021=SLEEP AS ANDROID MEASUREMENT, at0020=null}}}";


    String secondTestMetaData = "Id,Tz,From,To,Sched,Hours,Rating,Comment,Framerate,Snore,Noise,Cycles,DeepSleep,LenAdjust,Geo,13:52,13:52,Event";
    String secondTestData = "1413892330747,Europe/Sarajevo,21. 10. 2014 13:52,21. 10. 2014 13:52,02. 11. 2014 13:32,0.010,0.0, #home,10000,-1,-1.0,-1,-2.0,0,e069ca2,1.578773,1.9942772,TRACKING_STOPPED_BY_USER-1413892356303";
    String secondTestObjectModel = "{at0000={at0001={at0002={at0003={at0007={at0009=10000, at0014= #home, at0015=, at0004=0.010, at0005=21. 10. 2014 13:52, at0006=21. 10. 2014 13:52}, at0008={at0018={at0012={}, at0011={}, at0010={13:52=1.9942772}, at0013={}}, at0017={}}}}}, at0016={at0019=unknown sdk_google_phone_x86, at0021=SLEEP AS ANDROID MEASUREMENT, at0020=null}}}";

    String thirdTestMetaData = "Id,Tz,From,To,Sched,Hours,Rating,Comment,Framerate,Snore,Noise,Cycles,DeepSleep,LenAdjust,Geo,23:40,23:46,23:52,23:58,0:04,0:09,0:15,0:21,0:27,0:33,0:39,0:44,0:50,0:56,1:02,1:08,1:13,1:19,1:25,1:31,1:37,1:43,1:48,1:54,2:00,2:06,2:12,2:17,2:23,2:29,2:35,2:41,2:47,2:52,2:58,3:04,3:10,3:16,3:21,3:27,3:33,3:39,3:45,3:51,3:56,4:02,4:08,4:14,4:20,4:25,4:31,4:37,4:43,4:49,4:55,5:00,5:06,5:12,5:18,5:24,5:30,5:35,5:41,5:47,5:53,5:59,6:04,6:10,6:16,6:22,6:28,6:34,6:39,6:45,6:51,6:57,7:03,7:08,7:14,7:20,7:26,7:32,7:38,7:43,7:49,7:55,8:01,Event,Event,Event,Event,Event,Event,Event,Event,Event,Event";
    String thirdTestData = "1413840901140,Europe/Sarajevo,20. 10. 2014 23:35,21. 10. 2014 8:01,21. 10. 2014 8:15,8.440,0.0,,10000,-1,-1.0,-1,-1.0,-4,,2.6995342,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-0.001,-7.5E-4,-5.0E-4,-0.001,-0.001,-7.4915175E-4,-0.001,-0.001,0.098779954,TRACKING_PAUSED-1413841045938,TRACKING_RESUMED-1413841132756,BROKEN_START-1413841250312,TRACKING_PAUSED-1413842427058,TRACKING_RESUMED-1413842650073,ALARM_EARLIEST-1413870300000,BROKEN_END-1413870929932,ALARM_STARTED-1413871214561,ALARM_DISMISS-1413871276978,ALARM_LATEST-1413872100000";
    String thirdTestObjectModel = "{at0000={at0001={at0002={at0003={at0007={at0009=10000, at0014=, at0015=, at0004=8.440, at0005=20. 10. 2014 23:35, at0006=21. 10. 2014 8:01}, at0008={at0018={at0012={8:01=0.098779954}, at0011={}, at0010={7:26=-5.0E-4, 7:43=-7.4915175E-4, 23:40=2.6995342, 7:20=-7.5E-4}, at0013={3:33=-0.001, 6:04=-0.001, 7:03=-0.001, 23:52=-0.001, 7:49=-0.001, 2:00=-0.001, 4:25=-0.001, 3:51=-0.001, 5:24=-0.001, 2:12=-0.001, 1:02=-0.001, 0:44=-0.001, 7:55=-0.001, 7:38=-0.001, 2:47=-0.001, 3:16=-0.001, 5:30=-0.001, 3:56=-0.001, 7:14=-0.001, 6:28=-0.001, 6:45=-0.001, 0:04=-0.001, 6:57=-0.001, 1:43=-0.001, 3:27=-0.001, 2:29=-0.001, 0:09=-0.001, 4:37=-0.001, 3:21=-0.001, 6:51=-0.001, 5:41=-0.001, 7:08=-0.001, 1:25=-0.001, 2:06=-0.001, 5:59=-0.001, 3:04=-0.001, 4:02=-0.001, 1:19=-0.001, 2:35=-0.001, 0:50=-0.001, 5:35=-0.001, 0:21=-0.001, 1:54=-0.001, 5:47=-0.001, 1:48=-0.001, 4:20=-0.001, 4:55=-0.001, 2:17=-0.001, 1:08=-0.001, 23:58=-0.001, 0:15=-0.001, 3:39=-0.001, 1:13=-0.001, 0:56=-0.001, 2:58=-0.001, 6:22=-0.001, 6:39=-0.001, 2:23=-0.001, 2:52=-0.001, 5:06=-0.001, 23:46=-0.001, 4:43=-0.001, 5:18=-0.001, 2:41=-0.001, 4:14=-0.001, 4:49=-0.001, 6:10=-0.001, 3:45=-0.001, 5:12=-0.001, 0:33=-0.001, 5:53=-0.001, 0:27=-0.001, 5:00=-0.001, 0:39=-0.001, 3:10=-0.001, 6:16=-0.001, 1:31=-0.001, 7:32=-0.001, 1:37=-0.001, 4:08=-0.001, 4:31=-0.001, 6:34=-0.001}}, at0017={}}}}}, at0016={at0019=unknown sdk_google_phone_x86, at0021=SLEEP AS ANDROID MEASUREMENT, at0020=null}}}";


    @Before
    public void setUp(){
        firstSleepMeasurement = new SleepAsAndroidMeasurement(firstTestMetaData, firstTestData);
        secondSleepMeasurement = new SleepAsAndroidMeasurement(secondTestMetaData, secondTestData);
        thirdSleepMeasurement = new SleepAsAndroidMeasurement(thirdTestMetaData, thirdTestData);

    }

    @Test
    public void testFirstObjectModel() throws Exception {
        HashMap<String, Object> firstObjectModel = firstSleepMeasurement.getObjectModel();
        String result = firstObjectModel.toString();
        assertTrue(firstTestObjectModel.equals(result));
    }

    @Test
    public void testSecondObjectModel() throws Exception {
        HashMap<String, Object> secondObjectModel = secondSleepMeasurement.getObjectModel();
        String result = secondObjectModel.toString();
        assertTrue(secondTestObjectModel.equals(result));
    }

    @Test
    public void testThirdObjectModel() throws Exception {
        HashMap<String, Object> thirdObjectModel = thirdSleepMeasurement.getObjectModel();
        String result = thirdObjectModel.toString();
        assertTrue(thirdTestObjectModel.equals(result));
    }


}