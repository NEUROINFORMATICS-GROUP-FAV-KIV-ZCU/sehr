package com.example.root.medicaldatacollection;

import android.test.InstrumentationTestCase;

import org.junit.Before;
import org.junit.Test;


import java.util.HashMap;

/**
 * This class provide SleepDocumentation getting mapRepresentation tests.
 * <p/>
 * Created by root on 25.4.16.
 *
 * @author Jiri Matyas
 * @version 1.0
 */
public class SleepDocumentationTest extends InstrumentationTestCase {
    SleepDocumentation firstDocumentation;
    SleepDocumentation secondDocumentation;
    SleepDocumentation thirdDocumentation;

    String firstTestId = "ID_1";
    String secondTestId = "015";
    String thirdTestId = "sdfasjdfioajeifasidfjaiosdf";

    String firstTestTitle = "Title_1";
    String secondTestTitle = "015";
    String thirdTestTitle = "sdfasjdfioajeifasidfjaiosdf";

    String archetypeString = "archetypeString";

    String firstMapTestRepresentation = "{type=SLEEP_DOC, archetype_string=archetypeString, title=Title_1}";
    String secondTestMapRepresentation = "{type=SLEEP_DOC, archetype_string=archetypeString, title=015}";
    String thirdTestMapRepresentation = "{type=SLEEP_DOC, archetype_string=archetypeString, title=sdfasjdfioajeifasidfjaiosdf}";

    @Before
    public void setUp() {
        firstDocumentation = new SleepDocumentation(firstTestId, firstTestTitle, archetypeString);
        secondDocumentation = new SleepDocumentation(secondTestId, secondTestTitle, archetypeString);
        thirdDocumentation = new SleepDocumentation(thirdTestId, thirdTestTitle, archetypeString);
    }

    @Test
    public void testFirstObjectModel() throws Exception {
        HashMap<String, Object> firstMapRepresentation = firstDocumentation.getMapRepresentation();
        String result = firstMapRepresentation.toString();
        assertTrue(result.equals(firstMapTestRepresentation));
    }

    @Test
    public void testSecondObjectModel() throws Exception {
        HashMap<String, Object> secondMapRepresentation = secondDocumentation.getMapRepresentation();
        String result = secondMapRepresentation.toString();
        assertTrue(result.equals(secondTestMapRepresentation));
    }

    @Test
    public void testThirdObjectModel() throws Exception {
        HashMap<String, Object> thirdMapRepresentation = thirdDocumentation.getMapRepresentation();
        String result = thirdMapRepresentation.toString();
        assertTrue(result.equals(thirdTestMapRepresentation));
    }
}